# Herobrine v2.153 — NeoForge 1.21.1 source

Based on v2.152.

- Localized entity display name: `entity.herobrine.herobrine` → `Herobrine`.
- Cursed sword stalking: first sighting shortly after acquisition; thereafter 30–60 seconds; lasts 6–10 seconds, 25–45 blocks away, usually ahead of the player, tries loaded unobstructed ground and vanishes within 8 blocks. Client-only. F9 toggles diagnostic chat messages.
- Bedrock armor equipped textures: enhanced charcoal/gray pixel contrast while retaining exact original alpha mask, dimensions and UV mapping.
- No intentional changes to damage handlers, armor resistances, sword stats, enchantments, boss phases or loot.

## Testing

Source packaged, not compiled or tested against ATM10. Test F9 diagnostics, stalking renderer, entity death message, armor UV, armor piercing and permanent enchantments in game. Bedrock Armor versus Quantum-family weapons remains unverified.
