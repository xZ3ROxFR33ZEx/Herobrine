package com.herobrineboss;

import com.herobrineboss.entity.HerobrineEntity;
import com.herobrineboss.combat.CombatEvents;
import net.neoforged.neoforge.common.NeoForge;
import com.herobrineboss.entity.HerobrineCloneEntity;
import com.herobrineboss.registry.ModEntities;
import com.herobrineboss.registry.ModItems;
import net.minecraft.world.item.CreativeModeTabs;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;

@Mod(HerobrineMod.MOD_ID)
public class HerobrineMod {
    public static final String MOD_ID = "herobrine";
    public HerobrineMod(IEventBus modBus) {
        NeoForge.EVENT_BUS.register(CombatEvents.class);
        ModEntities.ENTITY_TYPES.register(modBus);
        ModItems.ARMOR_MATERIALS.register(modBus);
        ModItems.ITEMS.register(modBus);
        modBus.addListener(this::addCreativeItems);
        modBus.addListener(this::registerAttributes);
    }
    private void addCreativeItems(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.COMBAT) {
            event.accept(ModItems.BEDROCK_SWORD.get());
            event.accept(ModItems.CURSED_BEDROCK_SWORD.get());
            event.accept(ModItems.CREATORS_BLADE.get());
            event.accept(ModItems.BEDROCK_HELMET.get());
            event.accept(ModItems.BEDROCK_CHESTPLATE.get());
            event.accept(ModItems.BEDROCK_LEGGINGS.get());
            event.accept(ModItems.BEDROCK_BOOTS.get());
        }
    }
    private void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.HEROBRINE.get(), HerobrineEntity.createAttributes().build());
        event.put(ModEntities.HEROBRINE_CLONE.get(), HerobrineCloneEntity.createCloneAttributes().build());
    }
}
