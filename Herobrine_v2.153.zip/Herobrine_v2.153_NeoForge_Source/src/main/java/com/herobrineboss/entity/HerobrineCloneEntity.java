package com.herobrineboss.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** An independent decoy: never executes the main Herobrine boss AI. */
public class HerobrineCloneEntity extends HerobrineEntity {
    public enum TacticalRole { ATTACKER, FLANKER, DISTRACTOR, INTERCEPTOR }
    private TacticalRole tacticalRole = TacticalRole.ATTACKER;
    private int coordinatedAttackTicks = 0;
    private HerobrineEntity owner;
    private int lifespan = 600;
    private int attackCooldown = 35;
    private int illusionCooldown = 65;
    private int flightTicks = 0;
    private int flightDecisionCooldown = 25;
    private boolean cloneFlying = false;

    public HerobrineCloneEntity(EntityType<? extends HerobrineCloneEntity> type, Level level) {
        super(type, level);
        setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createCloneAttributes() {
        return Mob.createMobAttributes()
            .add(Attributes.MAX_HEALTH, 40.0)
            .add(Attributes.MOVEMENT_SPEED, 0.36)
            .add(Attributes.ATTACK_DAMAGE, 3.0)
            .add(Attributes.FOLLOW_RANGE, 64.0)
            .add(Attributes.ARMOR, 2.0)
            .add(Attributes.FLYING_SPEED, 0.35);
    }

    public void setOwner(HerobrineEntity owner) { this.owner = owner; }
    public TacticalRole getTacticalRole() { return tacticalRole; }
    public void setTacticalRole(TacticalRole role) { tacticalRole = role; }
    public void startCoordinatedAttack(int ticks) {
        coordinatedAttackTicks = Math.max(coordinatedAttackTicks, ticks);
        if (tacticalRole == TacticalRole.DISTRACTOR) illusionCooldown = Math.min(illusionCooldown, 8);
    }

    @Override public void tick() {
        super.tick(); // parent returns before boss mechanics for clone instances
        if (level().isClientSide()) return;
        if (--lifespan <= 0 || owner == null || !owner.isAlive()
                || owner.level() != level() || distanceToSqr(owner) > 128 * 128) {
            vanish();
            return;
        }
        if (attackCooldown > 0) attackCooldown--;
        if (illusionCooldown > 0) illusionCooldown--;
        if (coordinatedAttackTicks > 0) coordinatedAttackTicks--;
        LivingEntity target = getTarget();
        if (target == null || !target.isAlive()) {
            target = owner.getTarget();
            if (target != null && target.isAlive()) setTarget(target);
        }
        if (target == null || !target.isAlive()) {
            endFlight();
            return;
        }
        double distance = distanceToSqr(target);

        // v2.071: independent aerial pursuit, no boss abilities inherited.
        if (flightDecisionCooldown > 0) flightDecisionCooldown--;
        if (flightDecisionCooldown == 0) {
            flightDecisionCooldown = 60;
            float flyChance = tacticalRole == TacticalRole.INTERCEPTOR ? 0.85f
                : tacticalRole == TacticalRole.DISTRACTOR ? 0.75f : 0.55f;
            if (!cloneFlying && (target.getY() > getY() + 3.0 || random.nextFloat() < flyChance)) {
                cloneFlying = true;
                flightTicks = 65 + random.nextInt(65);
                setCloneFlyingAnimation(true);
                getNavigation().stop();
            }
        }
        if (cloneFlying) {
            if (--flightTicks <= 0 && target.getY() <= getY() + 3.0) {
                endFlight();
            } else {
                flyToward(target);
            }
        } else if (distance > 8.0) {
            setNoGravity(false);
            if (tacticalRole == TacticalRole.FLANKER) {
                Vec3 sideways = new Vec3(-(target.getZ() - getZ()), 0,
                    target.getX() - getX()).normalize().scale(getId() % 2 == 0 ? 5 : -5);
                getNavigation().moveTo(target.getX() + sideways.x,
                    target.getY(), target.getZ() + sideways.z, 1.25);
            } else if (tacticalRole == TacticalRole.DISTRACTOR && distance < 11 * 11) {
                getNavigation().moveTo(getX() + (getX() - target.getX()) * 0.35,
                    getY(), getZ() + (getZ() - target.getZ()) * 0.35, 1.1);
            } else {
                getNavigation().moveTo(target, tacticalRole == TacticalRole.INTERCEPTOR ? 1.45 : 1.15);
            }
        } else {
            getNavigation().stop();
        }

        if (distance <= 9.0 && attackCooldown == 0
                && tacticalRole != TacticalRole.DISTRACTOR) {
                target.hurt(damageSources().mobAttack(this), 3.0f);
                triggerAnim("actions", "melee");
                attackCooldown = coordinatedAttackTicks > 0 ? 22 : 32;
        }
        // A deliberately harmless fake beam: players must distinguish the true boss.
        if (illusionCooldown == 0 && distance < 32 * 32
                && level() instanceof ServerLevel server) {
            Vec3 start = getEyePosition();
            Vec3 delta = target.getEyePosition().subtract(start);
            if (delta.lengthSqr() > 0.01) {
                Vec3 direction = delta.normalize();
                for (double step = 0; step < Math.min(18, delta.length()); step += 0.7) {
                    Vec3 point = start.add(direction.scale(step));
                    server.sendParticles(ParticleTypes.SOUL_FIRE_FLAME,
                        point.x, point.y, point.z, 1, 0.04, 0.04, 0.04, 0.0);
                }
            }
            triggerAnim("actions", "beam_charge");
            illusionCooldown = tacticalRole == TacticalRole.DISTRACTOR
                ? 42 + random.nextInt(20) : 100 + random.nextInt(45);
        }
    }

    private void endFlight() {
        cloneFlying = false;
        setCloneFlyingAnimation(false);
        setNoGravity(false);
    }

    private void flyToward(LivingEntity target) {
        setNoGravity(true);
        getNavigation().stop();
        Vec3 difference = target.position().subtract(position());
        Vec3 horizontal = new Vec3(difference.x, 0, difference.z);
        double range = horizontal.length();
        Vec3 direction = range > 0.001 ? horizontal.scale(1.0 / range) : Vec3.ZERO;
        Vec3 lateral = new Vec3(-direction.z, 0, direction.x);
        // Keep a visible arc around the player instead of stacking on top of them.
        double preferredRange = tacticalRole == TacticalRole.DISTRACTOR ? 13.0
            : tacticalRole == TacticalRole.FLANKER ? 7.5 : 5.5;
        double forward = range > preferredRange + 2.0 ? 0.34
            : range < preferredRange - 2.0 ? -0.22 : 0.0;
        double orbit = (getId() % 2 == 0 ? 1.0 : -1.0)
            * (tacticalRole == TacticalRole.FLANKER ? 0.33
                : tacticalRole == TacticalRole.DISTRACTOR ? 0.25 : 0.13);
        double desiredY = target.getY() + 2.5 + (getId() % 3);
        double vertical = Math.max(-0.22, Math.min(0.22, (desiredY - getY()) * 0.09));
        Vec3 desired = direction.scale(forward).add(lateral.scale(orbit))
            .add(0, vertical, 0);
        setDeltaMovement(getDeltaMovement().scale(0.68).add(desired.scale(0.32)));
        hasImpulse = true;
        fallDistance = 0.0f;
    }

    private void vanish() {
        endFlight();
        if (level() instanceof ServerLevel server)
            server.sendParticles(ParticleTypes.SOUL, getX(), getY() + 1, getZ(),
                32, 0.5, 0.8, 0.5, 0.08);
        discard();
    }

    @Override public boolean hurt(DamageSource source, float amount) {
        if (source.getEntity() == owner) return false;
        boolean accepted = super.hurt(source, amount);
        if (accepted && !isAlive()) vanish();
        return accepted;
    }
}
