package com.herobrineboss.entity;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.entity.Display;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.entity.monster.warden.Warden;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.boss.enderdragon.phases.EnderDragonPhase;
import net.minecraft.world.entity.boss.enderdragon.phases.DragonStrafePlayerPhase;
import net.minecraft.world.entity.projectile.DragonFireball;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.minecraft.world.entity.schedule.Activity;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.GameRules;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.server.level.ServerLevel;
import com.herobrineboss.registry.ModEntities;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.world.BossEvent;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.RandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.level.ClipContext;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.AnimatableManager;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

/** Server-authoritative combat prototype. Ability visuals are synchronized with GeckoLib triggers. */
public class HerobrineEntity extends Monster implements GeoEntity {
    public static final int DETECTION_RADIUS = 96;
    public static final int TELEPORT_COOLDOWN_TICKS = 60;
    public static final double AERIAL_COMBAT_CHANCE = 0.70;
    public static final int MAX_COMBO_HITS = 5;

    private static final RawAnimation IDLE = RawAnimation.begin().thenLoop("anim.herobrine.idle");
    private static final RawAnimation WALK = RawAnimation.begin().thenLoop("anim.herobrine.walk");
    private static final RawAnimation RUN = RawAnimation.begin().thenLoop("anim.herobrine.run");
    private static final RawAnimation FLY_IDLE = RawAnimation.begin().thenLoop("anim.herobrine.fly_idle");
    private static final RawAnimation FLY_FORWARD = RawAnimation.begin().thenLoop("anim.herobrine.fly_forward");
    private static final EntityDataAccessor<Boolean> FLYING = SynchedEntityData.defineId(HerobrineEntity.class, EntityDataSerializers.BOOLEAN);
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    // Server-side ability state; projectiles and temporary walls are cleaned up automatically.
    // v1.8: summoning is server-side, limited, and telegraphed.
    private static final int SUMMON_COOLDOWN_TICKS = 20 * 75;
    private static final int SUMMON_RETRY_TICKS = 20 * 8;
    private static final int SUMMON_WINDUP_TICKS = 32;
    private static final int SUMMON_TARGET_REFRESH_TICKS = 10;
    private static final int MAX_WITHERS = 2;
    private static final int MAX_WARDENS = 2;
    private int summonCooldown = 20 * 12;
    private int summonWindup = 0;
    private boolean pendingWithers = false;
    private boolean summonNextWithers = true;
    private final List<WitherBoss> summonedWithers = new ArrayList<>();
    private final List<Warden> summonedWardens = new ArrayList<>();
    // v2.0: one dragon encounter per Herobrine lifetime, followed by an enraged phase.
    private EnderDragon summonedDragon;
    private int dragonLowHealthTicks = 0;
    private boolean dragonDeathStarted = false;
    private Vec3 dragonReturnPosition = Vec3.ZERO;
    private final ServerBossEvent bossBar = new ServerBossEvent(
        Component.literal("Herobrine"), BossEvent.BossBarColor.PURPLE,
        BossEvent.BossBarOverlay.PROGRESS);
    // v2.07: decoys are separate entities and never run boss/dragon AI.
    private static final int CLONE_CAP = 5;
    private int cloneSummonCooldown = 180;
    private int cloneSwapCooldown = 120;
    private final List<HerobrineCloneEntity> activeClones = new ArrayList<>();
    private int tacticalReassessmentTicks = 60;
    private int targetRedistributionTicks = 100;
    private int coordinatedAttackTicks = 260;
    private int coordinatedAttackDuration = 0;
    private int coordinationSequence = 0;
    private int burialCooldown = 160;
    private int healthRegenDelay = 0;
    private double armorReserve = 12.0;
    private boolean dragonPhaseStarted = false;
    private boolean finalPhase = false;
    private int dragonSummonWindup = 0;
    private int dragonRidingAttackCooldown = 0;
    private int dragonFireballCooldown = 0;
    private int dragonSwoopCooldown = 0;
    private int dragonContactCooldown = 0;
    private int dragonOrbitDirection = 1;
    private boolean dragonSwooping = false;
    private int dragonSwoopTicks = 0;
    private int wardenPulseCooldown = 0;
    private int finalPhaseWindup = 0;
    private int bedrockCooldown = 0;
    private int wallCooldown = 0;
    private int slamCooldown = 0;
    // v2.06 controlled battlefield destruction. Never force-load chunks.
    private int fissureCooldown = 180;
    private int collapseCooldown = 280;
    private static final int MAX_TERRAIN_BLOCKS_PER_ATTACK = 48;
    private static final float MAX_DESTRUCTIBLE_HARDNESS = 12.0f;
    private int barrageShots = 0;
    private int barrageDelay = 0;
    private int heldBlockTicks = 0;
    private Display.BlockDisplay heldBlock;
    private final List<BedrockShot> shots = new ArrayList<>();
    private final List<TemporaryWallBlock> wallBlocks = new ArrayList<>();
    private int teleportCooldown = 0;
    private int attackCooldown = 0;
    private int combatDecisionCooldown = 0;
    private int flightTicks = 0;
    private int comboRemaining = 0;
    private boolean flying = false;

    // v2.01 defensive ranged combat: all ability decisions run server-side.
    private static final int DEFENSIVE_TELEPORT_TICKS = 30;
    private static final double MIN_RANGED_DISTANCE = 12.0;
    private static final double MAX_RANGED_DISTANCE = 20.0;
    private int defensiveTeleportCooldown = 0;
    private int beamCooldown = 100;
    private int beamChargeTicks = 0;
    private Vec3 beamLockedDirection = Vec3.ZERO;
    private int strafeDirection = 1;
    private int strafeChangeCooldown = 0;
    private int hitFeedbackTicks = 0;
    // v2.04: lightweight, server-side adaptive combat state (no machine learning).
    private int adaptiveCheckCooldown = 0;
    private int evasiveStrafeTicks = 0;
    private int pressureTicks = 0;
    private int lostSightTicks = 0;
    private int targetSwitchCooldown = 0;
    private float observedTargetHealth = -1.0f;
    private LivingEntity observedTarget = null;
    private Vec3 lastObservedTargetPos = Vec3.ZERO;
    private int targetStillTicks = 0;
    // v2.05 advanced defense: a brief, telegraphed shield after sustained pressure.
    private static final int SHIELD_DURATION_TICKS = 80;
    private static final int SHIELD_COOLDOWN_TICKS = 500;
    private int shieldTicks = 0;
    private int shieldCooldown = 100;
    private int consecutiveHitWindow = 0;
    private int consecutiveHits = 0;
    private int counterattackCooldown = 0;
    private int deflectedProjectiles = 0;



    @Override protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(FLYING, false);
    }

    public HerobrineEntity(EntityType<? extends HerobrineEntity> type, Level level) { super(type, level); }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes().add(Attributes.MAX_HEALTH, 300.0)
            .add(Attributes.MOVEMENT_SPEED, 0.32).add(Attributes.ATTACK_DAMAGE, 12.0)
            .add(Attributes.FOLLOW_RANGE, DETECTION_RADIUS).add(Attributes.ARMOR, 12.0)
            .add(Attributes.FLYING_SPEED, 0.55);
    }

    @Override protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        // Melee is handled below to synchronize individual hit frames and combo timing.
        // Random strolling makes Herobrine retreat or wander during combat.
        // His ranged-combat movement is managed directly in tick().
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 16f));
        goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        targetSelector.addGoal(0, new HurtByTargetGoal(this));
        targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override public void tick() {
        super.tick();
        if (level().isClientSide() || this instanceof HerobrineCloneEntity) return;
        if (cloneSummonCooldown > 0) cloneSummonCooldown--;
        if (cloneSwapCooldown > 0) cloneSwapCooldown--;
        if (tickCount % 20 == 0) activeClones.removeIf(c -> !c.isAlive() || c.isRemoved());
        if (tacticalReassessmentTicks > 0) tacticalReassessmentTicks--;
        if (targetRedistributionTicks > 0) targetRedistributionTicks--;
        if (coordinatedAttackTicks > 0) coordinatedAttackTicks--;
        if (coordinatedAttackDuration > 0) coordinatedAttackDuration--;
        if (tacticalReassessmentTicks == 0 || targetRedistributionTicks == 0
                || coordinatedAttackTicks == 0) coordinateClones();

        if (getRemainingFireTicks() > 0) clearFire();
        tickBedrockVisuals();
        if (summonCooldown > 0) summonCooldown--;
        if (defensiveTeleportCooldown > 0) defensiveTeleportCooldown--;
        if (beamCooldown > 0) beamCooldown--;
        if (strafeChangeCooldown > 0) strafeChangeCooldown--;
        if (hitFeedbackTicks > 0) hitFeedbackTicks--;
        if (adaptiveCheckCooldown > 0) adaptiveCheckCooldown--;
        if (evasiveStrafeTicks > 0) evasiveStrafeTicks--;
        if (pressureTicks > 0) pressureTicks--;
        if (targetSwitchCooldown > 0) targetSwitchCooldown--;
        if (shieldTicks > 0) shieldTicks--;
        if (shieldCooldown > 0) shieldCooldown--;
        if (counterattackCooldown > 0) counterattackCooldown--;
        if (consecutiveHitWindow > 0) consecutiveHitWindow--;
        else consecutiveHits = 0;
        if (shieldTicks > 0) {
            tickDefensiveShield();
        }


        bossBar.setProgress(Math.max(0.0f, Math.min(1.0f, getHealth() / getMaxHealth())));
        if (healthRegenDelay > 0) healthRegenDelay--;
        else if (tickCount % 10 == 0 && getHealth() < getMaxHealth())
            heal(1.0f);
        if (tickCount % 40 == 0 && armorReserve < 20.0) {
            armorReserve = Math.min(20.0, armorReserve + 1.0);
            var armorAttribute = getAttribute(Attributes.ARMOR);
            if (armorAttribute != null) armorAttribute.setBaseValue(armorReserve);
        }
        if (burialCooldown > 0) burialCooldown--;
        if (burialCooldown == 0 && getTarget() instanceof ServerPlayer player
                && !player.getAbilities().flying && !player.isFallFlying()
                && player.onGround() && !player.isCreative() && !player.isSpectator()
                && distanceToSqr(player) <= 24 * 24
                && level().getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING)) {
            tryBuryPlayer(player);
        }
        if (dragonRidingAttackCooldown > 0) dragonRidingAttackCooldown--;
        if (dragonFireballCooldown > 0) dragonFireballCooldown--;
        if (dragonSwoopCooldown > 0) dragonSwoopCooldown--;
        if (dragonContactCooldown > 0) dragonContactCooldown--;
        if (wardenPulseCooldown > 0) wardenPulseCooldown--;
        if (finalPhaseWindup > 0) finalPhaseWindup--;
        if (dragonSummonWindup > 0 && --dragonSummonWindup == 0) spawnDragon();
        if (dragonPhaseStarted && !finalPhase && dragonSummonWindup == 0) {
            if (summonedDragon == null || summonedDragon.isRemoved()) {
                beginFinalPhase();
            } else {
                EnderDragon dragon = summonedDragon;
                // Death starts when health reaches zero, not after it disappears.
                if (dragon.getHealth() <= 0.0f) {
                    if (!dragonDeathStarted) {
                        dragonDeathStarted = true;
                        dragonReturnPosition = position();
                        safeDismountFromDragon();
                    }
                } else if (dragon.getHealth() <= 1.0f) {
                    // Vanilla dragon damage can stall at 1 HP if its phase keeps
                    // being reset. Give it 5 seconds before triggering death.
                    if (++dragonLowHealthTicks >= 100) {
                        dragon.setHealth(0.0f);
                        dragonDeathStarted = true;
                        safeDismountFromDragon();
                    }
                } else dragonLowHealthTicks = 0;
            }
        }
        if (summonWindup > 0 && --summonWindup == 0) finishSummoning();
        if (tickCount % SUMMON_TARGET_REFRESH_TICKS == 0) {
            maintainSummonedReinforcements();
        }
        if (bedrockCooldown > 0) bedrockCooldown--;
        if (wallCooldown > 0) wallCooldown--;
        if (slamCooldown > 0) slamCooldown--;
        if (fissureCooldown > 0) fissureCooldown--;
        if (collapseCooldown > 0) collapseCooldown--;
        if (teleportCooldown > 0) teleportCooldown--;
        if (attackCooldown > 0) attackCooldown--;
        if (combatDecisionCooldown > 0) combatDecisionCooldown--;
        if (beamChargeTicks > 0 && --beamChargeTicks == 0) fireEnergyBeam();

        LivingEntity target = getTarget();
        if (target == null || !target.isAlive() || (target instanceof Player p && (p.isCreative() || p.isSpectator()))) {
            comboRemaining = 0;
            stopFlight();
            return;
        }
        // Clones only appear during normal combat, not while mounted or transforming.
        if (!isDragonEncounterActive() && dragonSummonWindup == 0 && finalPhaseWindup == 0
                && cloneSummonCooldown == 0 && distanceToSqr(target) < 48 * 48) {
            summonClones(target);
        }
        // Observe player behavior before combat decisions; don't override dragon flight.
        tickAdaptiveCombat(target);
        // Dragon transition at half health; only one dragon is created.
        if (!dragonPhaseStarted && getHealth() <= getMaxHealth() * 0.5f) beginDragonPhase();
        if (dragonSummonWindup > 0 || finalPhaseWindup > 0) {
            getNavigation().stop();
            return;
        }
        if (isDragonEncounterActive()) {
            // No 12–20-block spacing while the dragon is alive.
            // Keep mounted attacks and the vanilla dragon flight controller intact.
            getNavigation().stop();
            stopFlight();
            tickDragonCombat(target);
            return;
        }
        double distanceSq = distanceToSqr(target);
        if (distanceSq > DETECTION_RADIUS * DETECTION_RADIUS) {
            setTarget(null);
            stopFlight();
            return;
        }
        getLookControl().setLookAt(target, 30f, 30f);
        if (beamChargeTicks > 0) {
            // Track while charging, then lock the direction when firing.
            Vec3 origin = getEyePosition();
            Vec3 aimPoint = predictedTargetPoint(target, 5.0);
            Vec3 aim = aimPoint.subtract(origin);
            if (aim.lengthSqr() > 0.001) beamLockedDirection = aim.normalize();
            if (level() instanceof ServerLevel server && tickCount % 3 == 0) {
                server.sendParticles(ParticleTypes.END_ROD, origin.x, origin.y, origin.z,
                    8, 0.25, 0.25, 0.25, 0.015);
            }
        } else if (beamCooldown == 0 && distanceSq > 64 && distanceSq < 1600
                && hasLineOfSight(target)) {
            beamChargeTicks = 40; // Two-second visible charge.
            beamCooldown = 140;
            triggerAnim("actions", "beam_charge");
        }
        // Alternate reinforcement types whenever possible, instead of choosing only by distance.
        if (summonCooldown == 0 && summonWindup == 0 && distanceSq < 48 * 48) {
            summonedWithers.removeIf(e -> !e.isAlive() || e.isRemoved());
            summonedWardens.removeIf(e -> !e.isAlive() || e.isRemoved());
            boolean canWithers = summonedWithers.size() < MAX_WITHERS;
            boolean canWardens = summonedWardens.size() < MAX_WARDENS;
            if (canWithers || canWardens) {
                boolean chooseWithers = canWithers && (!canWardens || summonNextWithers);
                beginSummoning(chooseWithers);
            } else {
                summonCooldown = 20 * 10;
            }
        }
        if (barrageShots > 0) {
            if (--barrageDelay <= 0) {
                launchBedrock(target);
                barrageShots--;
                barrageDelay = 8;
            }
        } else if (heldBlockTicks > 0) {
            if (--heldBlockTicks == 0) {
                removeHeldBlock();
                launchTelekineticVolley(target);
                triggerAnim("actions", "bedrock_throw");
            }
        } else if (bedrockCooldown == 0 && distanceSq > 16 && distanceSq < 1600) {
            chooseBedrockAttack(target);
            if (pressureTicks > 0) bedrockCooldown = Math.max(50, bedrockCooldown - 20);
        }
        if (distanceSq < 30 && slamCooldown == 0 && random.nextInt(55) == 0) groundSlam(target);
        if (fissureCooldown == 0 && distanceSq >= 25 && distanceSq < 625 && random.nextInt(35) == 0)
            eruptFissure(target);
        if (collapseCooldown == 0 && distanceSq >= 16 && distanceSq < 400 && random.nextInt(45) == 0)
            collapseGround(target);
        if (wallCooldown == 0 && nearbyThreatCount() >= 3) raiseWall(target);

        // Re-evaluate the combat stance periodically: 70% chance to choose an aerial window.
        if (combatDecisionCooldown == 0) {
            combatDecisionCooldown = 60;
            if (random.nextDouble() < AERIAL_COMBAT_CHANCE) {
                flying = true;
                entityData.set(FLYING, true);
                flightTicks = 50 + random.nextInt(50);
            } else stopFlight();
        }
        if (flying) {
            flightTicks--;
            if (flightTicks <= 0) stopFlight();
            else pursueInAir(target);
        } else {
            setNoGravity(false);
            pursueOnGround(target);
        }

        // Teleport behind the player when distant or periodically during combat.
        // No offensive teleport toward/behind the player: v2.01 defensive
        // teleport remains available after hits, but no random fleeing/wandering.

        // Up to five strikes, each on its own cooldown. Only damage within melee range.
        if (distanceToSqr(target) <= 9.0 && attackCooldown == 0 && beamChargeTicks == 0
                && hasLineOfSight(target)) {
            if (comboRemaining <= 0) comboRemaining = 1 + random.nextInt(MAX_COMBO_HITS);
            boolean heavy = comboRemaining == 1 && random.nextInt(4) == 0;
            triggerAnim("actions", heavy ? "knockback" : "melee");
            doHurtTarget(target);
            if (heavy) {
                Vec3 away = target.position().subtract(position()).multiply(1, 0, 1).normalize();
                target.push(away.x * 1.1, 0.35, away.z * 1.1);
                target.hurtMarked = true;
            }
            comboRemaining--;
            attackCooldown = comboRemaining > 0 ? (finalPhase ? 7 : 11) : (finalPhase ? 14 : 22);
        }
    }

    private void beginDragonPhase() {
        dragonPhaseStarted = true;
        dragonSummonWindup = 50;
        comboRemaining = 0;
        stopFlight();
        getNavigation().stop();
        triggerAnim("actions", "summon_dragon");
    }

    private void spawnDragon() {
        if (!(level() instanceof ServerLevel server) || !isAlive()) return;
        EnderDragon dragon = EntityType.ENDER_DRAGON.create(server);
        if (dragon == null) { beginFinalPhase(); return; }
        // Spawn clear of the ground. Test this in a disposable world: the vanilla
        // dragon's pathing and terrain destruction are designed for the End.
        dragon.moveTo(getX(), getY() + 12.0, getZ(), getYRot(), 0);
        if (!server.addFreshEntity(dragon)) { beginFinalPhase(); return; }
        summonedDragon = dragon;
        triggerAnim("actions", "dragon_mount");
        dragonFireballCooldown = 45;
        dragonSwoopCooldown = 45;
        dragonOrbitDirection = random.nextBoolean() ? 1 : -1;
        startRiding(dragon, true);
    }

    /** v2.031: let vanilla dragon flight control its position and rotation.
     *  Direct moveTo/setDeltaMovement overrides made the dragon jitter and glitch.
     *  Our existing offensive attacks remain active while it circles naturally.
     */
    private void tickDragonCombat(LivingEntity target) {
        if (!(level() instanceof ServerLevel server) || summonedDragon == null) return;
        EnderDragon dragon = summonedDragon;
        if (dragonDeathStarted || !dragon.isAlive() || dragon.getHealth() <= 0.0f || dragon.isRemoved()) return;
        double horizontal = Math.hypot(dragon.getX() - target.getX(), dragon.getZ() - target.getZ());

        // v2.034 flight tether: retain native dragon animation and phase movement.
        // The End's default holding pattern may otherwise fly to distant End nodes.
        if (tickCount % 20 == 0 && dragon.getHealth() > 0.0f) {
            // Repeatedly resetting the same phase interrupts vanilla dragon AI.
            if (dragon.getPhaseManager().getCurrentPhase().getPhase() != EnderDragonPhase.STRAFE_PLAYER)
                dragon.getPhaseManager().setPhase(EnderDragonPhase.STRAFE_PLAYER);
            if (dragon.getPhaseManager().getCurrentPhase() instanceof DragonStrafePlayerPhase strafe)
                strafe.setTarget(target);
        }
        // Rare safety fallback: restore the encounter if the dragon escapes its area.
        if (horizontal > 90.0 && dragon.getHealth() > 0.0f) {
            Vec3 back = target.position().add(24.0, 22.0, 0.0);
            dragon.moveTo(back.x, back.y, back.z, dragon.getYRot(), dragon.getXRot());
            dragon.getPhaseManager().setPhase(EnderDragonPhase.STRAFE_PLAYER);
            if (dragon.getPhaseManager().getCurrentPhase() instanceof DragonStrafePlayerPhase strafe) {
                strafe.setTarget(target);
            }
        }

        // Continue attempting to mount if vanilla dismounts Herobrine.
        if (!dragonDeathStarted && !isPassenger() && tickCount % 20 == 0) startRiding(dragon, true);

        // A close flyby can still damage the target without forcing a dive path.
        if (dragonContactCooldown == 0 && horizontal < 7.0
                && Math.abs(dragon.getY() - target.getY()) < 8.0) {
            com.herobrineboss.combat.CombatEvents.herobrineStrike(target, damageSources().mobAttack(this), 18.0f);
            Vec3 knock = target.position().subtract(dragon.position()).multiply(1, 0, 1);
            if (knock.lengthSqr() > 0.01) {
                knock = knock.normalize();
                target.push(knock.x * 1.7, 0.6, knock.z * 1.7);
            }
            dragonContactCooldown = 30;
            server.sendParticles(ParticleTypes.EXPLOSION, target.getX(), target.getY() + 1,
                target.getZ(), 5, 0.7, 0.5, 0.7, 0.03);
        }

        // Retain dragon fireball attack even while vanilla is orbiting.
        if (dragonFireballCooldown == 0 && horizontal < 60.0) {
            Vec3 origin = dragon.position().add(0, 3, 0);
            Vec3 direction = target.getEyePosition().subtract(origin);
            if (direction.lengthSqr() > 0.001) {
                Vec3 aim = direction.normalize();
                DragonFireball fireball = new DragonFireball(server, dragon, aim);
                fireball.moveTo(origin.x + aim.x * 3, origin.y + aim.y * 3,
                    origin.z + aim.z * 3, 0, 0);
                server.addFreshEntity(fireball);
                server.sendParticles(ParticleTypes.DRAGON_BREATH, origin.x, origin.y, origin.z,
                    28, 0.7, 0.5, 0.7, 0.04);
                dragonFireballCooldown = 90 + random.nextInt(45);
            }
        }

        // Herobrine continues his independent mounted bedrock attacks.
        if (dragonRidingAttackCooldown == 0 && horizontal < 40.0) {
            launchBedrock(target);
            triggerAnim("actions", "dragon_riding_attack");
            dragonRidingAttackCooldown = 50;
        }
    }

    /** Summoned Warden combat without vanilla DIG activity or despawning. */
    private void tickWardenAlly(Warden warden, LivingEntity target) {
        if (!(level() instanceof ServerLevel server)) return;
        double distance = warden.distanceTo(target);
        if (distance > 3.0 && distance < 48.0) {
            Vec3 direction = target.position().subtract(warden.position()).multiply(1, 0, 1);
            if (direction.lengthSqr() > 0.01) {
                direction = direction.normalize();
                Vec3 next = warden.position().add(direction.scale(0.18));
                if (server.noCollision(warden, warden.getBoundingBox().move(next.subtract(warden.position())))) {
                    warden.setPos(next.x, next.y, next.z);
                }
            }
        }
        if (wardenPulseCooldown == 0 && distance < 18.0 && distance > 3.0) {
            // Sonic-boom-style damage and particles; controlled by the boss.
            Vec3 start = warden.getEyePosition();
            Vec3 end = target.getEyePosition();
            Vec3 diff = end.subtract(start);
            for (int i = 0; i < 16; i++) {
                Vec3 point = start.add(diff.scale(i / 16.0));
                server.sendParticles(ParticleTypes.SONIC_BOOM, point.x, point.y, point.z,
                    1, 0, 0, 0, 0);
            }
            target.hurt(damageSources().sonicBoom(warden), 10.0f);
            wardenPulseCooldown = 65;
        } else if (distance <= 3.0 && wardenPulseCooldown == 0) {
            com.herobrineboss.combat.CombatEvents.herobrineStrike(target, damageSources().mobAttack(warden), 12.0f);
            wardenPulseCooldown = 35;
        }
    }

    /** v2.08: a single commander assigns roles, targets and attack windows.
     * Clone navigation remains independent, so it never controls dragon flight.
     */
    private void coordinateClones() {
        if (!(level() instanceof ServerLevel server) || this instanceof HerobrineCloneEntity)
            return;
        activeClones.removeIf(c -> !c.isAlive() || c.isRemoved());
        if (activeClones.isEmpty() || isDragonEncounterActive()) {
            tacticalReassessmentTicks = 60;
            targetRedistributionTicks = 100;
            coordinatedAttackTicks = 260;
            return;
        }
        List<Player> players = server.getEntitiesOfClass(Player.class,
            getBoundingBox().inflate(80),
            p -> p.isAlive() && !p.isCreative() && !p.isSpectator());
        if (players.isEmpty()) return;
        players.sort((a, b) -> Double.compare(a.distanceToSqr(this), b.distanceToSqr(this)));
        if (tacticalReassessmentTicks == 0) {
            for (int i = 0; i < activeClones.size(); i++) {
                HerobrineCloneEntity clone = activeClones.get(i);
                HerobrineCloneEntity.TacticalRole role;
                switch ((i + coordinationSequence) % 4) {
                    case 0: role = HerobrineCloneEntity.TacticalRole.ATTACKER; break;
                    case 1: role = HerobrineCloneEntity.TacticalRole.FLANKER; break;
                    case 2: role = HerobrineCloneEntity.TacticalRole.DISTRACTOR; break;
                    default: role = HerobrineCloneEntity.TacticalRole.INTERCEPTOR;
                }
                clone.setTacticalRole(role);
            }
            coordinationSequence++;
            tacticalReassessmentTicks = 60;
        }
        if (targetRedistributionTicks == 0) {
            for (int i = 0; i < activeClones.size(); i++) {
                HerobrineCloneEntity clone = activeClones.get(i);
                // Different players are pressured instead of all clones choosing
                // the closest target. Interceptors prioritize the farthest player.
                Player target = clone.getTacticalRole() ==
                    HerobrineCloneEntity.TacticalRole.INTERCEPTOR
                    ? players.get(players.size() - 1)
                    : players.get(i % players.size());
                clone.setTarget(target);
            }
            targetRedistributionTicks = 100;
        }
        if (coordinatedAttackTicks == 0) {
            coordinatedAttackDuration = 100; // five-second combined pressure
            coordinatedAttackTicks = 240 + random.nextInt(121); // 12-18 seconds
            for (HerobrineCloneEntity clone : activeClones)
                clone.startCoordinatedAttack(100);
            server.sendParticles(ParticleTypes.SOUL_FIRE_FLAME,
                getX(), getY() + 1.3, getZ(), 45, 1.1, 0.9, 1.1, 0.06);
            // The boss retains its own existing attack system. A coordinated
            // window accelerates readiness rather than spawning extra attacks.
            beamCooldown = Math.min(beamCooldown, 35);
            bedrockCooldown = Math.min(bedrockCooldown, 35);
        }
    }

    private void summonClones(LivingEntity target) {
        if (!(level() instanceof ServerLevel server)) return;
        activeClones.removeIf(c -> !c.isAlive() || c.isRemoved());
        int count = Math.min(3 + random.nextInt(3), CLONE_CAP - activeClones.size());
        for (int i = 0; i < count; i++) {
            HerobrineCloneEntity clone = ModEntities.HEROBRINE_CLONE.get().create(server);
            if (clone == null) continue;
            double angle = (Math.PI * 2 * i / Math.max(1, count)) + random.nextDouble() * 0.4;
            double radius = 5.0 + random.nextDouble() * 4.0;
            BlockPos start = BlockPos.containing(
                target.getX() + Math.cos(angle) * radius, target.getY(),
                target.getZ() + Math.sin(angle) * radius);
            BlockPos ground = server.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, start);
            clone.moveTo(ground.getX() + 0.5, ground.getY() + 0.2, ground.getZ() + 0.5,
                random.nextFloat() * 360f, 0);
            if (!server.noCollision(clone)) continue;
            clone.setOwner(this);
            clone.setTarget(target);
            if (server.addFreshEntity(clone)) {
                activeClones.add(clone);
                server.sendParticles(ParticleTypes.PORTAL, clone.getX(),
                    clone.getY() + 1, clone.getZ(), 28, 0.5, 0.9, 0.5, 0.12);
            }
        }
        cloneSummonCooldown = 1200; // 60 seconds
        tacticalReassessmentTicks = 1;
        targetRedistributionTicks = 1;
        triggerAnim("actions", "summon_wardens"); // existing summon gesture
    }

    private boolean swapWithClone(LivingEntity attacker) {
        if (!(level() instanceof ServerLevel server)) return false;
        activeClones.removeIf(c -> !c.isAlive() || c.isRemoved());
        HerobrineCloneEntity chosen = null;
        double best = 0;
        for (HerobrineCloneEntity clone : activeClones) {
            double separation = clone.distanceToSqr(this);
            if (separation > 16 && separation < 900 && separation > best) {
                best = separation;
                chosen = clone;
            }
        }
        if (chosen == null) return false;
        Vec3 oldPosition = position();
        Vec3 clonePosition = chosen.position();
        if (!server.noCollision(getBoundingBox().move(clonePosition.subtract(position()))))
            return false;
        if (!server.noCollision(chosen.getBoundingBox().move(oldPosition.subtract(clonePosition))))
            return false;
        server.sendParticles(ParticleTypes.PORTAL, getX(), getY() + 1, getZ(),
            35, 0.6, 1, 0.6, 0.14);
        triggerAnim("actions", "teleport_out");
        teleportTo(clonePosition.x, clonePosition.y, clonePosition.z);
        chosen.teleportTo(oldPosition.x, oldPosition.y, oldPosition.z);
        server.sendParticles(ParticleTypes.PORTAL, getX(), getY() + 1, getZ(),
            35, 0.6, 1, 0.6, 0.14);
        triggerAnim("actions", "teleport_in");
        cloneSwapCooldown = 400; // 20 seconds
        chosen.setTarget(attacker);
        return true;
    }

    private void safeDismountFromDragon() {
        if (isPassenger()) stopRiding();
        if (!(level() instanceof ServerLevel server)) return;
        LivingEntity target = getTarget();
        Vec3 center = target != null ? target.position() : dragonReturnPosition;
        BlockPos candidate = BlockPos.containing(center.x + 5, center.y, center.z + 5);
        BlockPos ground = server.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, candidate);
        teleportTo(ground.getX() + 0.5, ground.getY() + 1, ground.getZ() + 0.5);
        setNoGravity(false);
        setDeltaMovement(Vec3.ZERO);
    }

    private void tryBuryPlayer(ServerPlayer player) {
        if (!(level() instanceof ServerLevel server)) return;
        BlockPos feet = player.blockPosition();
        // Only bury inside existing mineable ground. Never create bedrock.
        BlockPos destination = feet.below(2);
        for (int dy = -2; dy <= 0; dy++) {
            BlockPos pos = feet.offset(0, dy, 0);
            BlockState state = server.getBlockState(pos);
            if (state.is(Blocks.BEDROCK) || state.getDestroySpeed(server, pos) < 0
                    || server.getBlockEntity(pos) != null) {
                burialCooldown = 60;
                return;
            }
        }
        if (!server.getBlockState(destination).isSolid()) {
            burialCooldown = 60;
            return;
        }
        // Existing surrounding terrain causes suffocation until the player digs out.
        player.teleportTo(destination.getX() + 0.5, destination.getY() + 0.1,
            destination.getZ() + 0.5);
        server.sendParticles(ParticleTypes.POOF, feet.getX() + 0.5,
            feet.getY() + 0.5, feet.getZ() + 0.5, 35, 0.5, 0.5, 0.5, 0.04);
        burialCooldown = 240;
    }

    private void beginFinalPhase() {
        if (finalPhase) return;
        finalPhase = true;
        if (dragonDeathStarted) safeDismountFromDragon();
        else stopRiding();
        summonedDragon = null;
        finalPhaseWindup = 45;
        stopFlight();
        getNavigation().stop();
        triggerAnim("actions", "dragon_dismount");
        triggerAnim("actions", "final_phase_transform");
        // Increase offensive stats without resetting Herobrine's current health.
        var damage = getAttribute(Attributes.ATTACK_DAMAGE);
        if (damage != null) damage.setBaseValue(20.0);
        var speed = getAttribute(Attributes.MOVEMENT_SPEED);
        if (speed != null) speed.setBaseValue(0.42);
        if (level() instanceof ServerLevel server) {
            server.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, getX(), getY() + 1.0, getZ(),
                120, 1.2, 1.5, 1.2, 0.08);
        }
    }

    // All potion/status effects are rejected (poison, wither, slowness, etc.).
    // Direct damage still works normally unless separately protected below.
    @Override public boolean canBeAffected(MobEffectInstance effect) {
        return false;
    }

    // A boss kill awards exactly one cursed sword, regardless of party size.
    private boolean cursedSwordDropped = false;
    @Override public void die(DamageSource source) {
        if (!level().isClientSide() && !(this instanceof HerobrineCloneEntity)
                && !cursedSwordDropped) {
            cursedSwordDropped = true;
            this.spawnAtLocation(com.herobrineboss.registry.ModItems.CURSED_BEDROCK_SWORD.get());
        }
        super.die(source);
    }

    @Override public boolean hurt(DamageSource source, float amount) {
        if (this instanceof HerobrineCloneEntity) return super.hurt(source, amount);
        if (com.herobrineboss.combat.CombatEvents.isIndustrialWeaponAttack(source)) return false;
        // Ignore fall and fire-based damage in every phase.
        if (source.is(DamageTypeTags.IS_FALL) || source.is(DamageTypeTags.IS_FIRE)) return false;
        // Invulnerable while the summoned dragon is alive, except creative-mode
        // bypass sources (e.g. /kill). Final phase becomes damageable again.
        if (!level().isClientSide() && dragonPhaseStarted && !finalPhase
                && summonedDragon != null && summonedDragon.isAlive()
                && !source.is(net.minecraft.tags.DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            return false;
        }
        // Reinforcements are allied: Wither body damage and Wither skulls
        // cannot injure their summoner, even if vanilla target selection misfires.
        if (!level().isClientSide() && source.getEntity() instanceof WitherBoss wither
                && summonedWithers.contains(wither)) return false;
        // Shield absorbs most, but never all, direct damage. Dragon phase immunity
        // remains controlled by the original rules above.
        if (shieldTicks > 0 && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            amount *= 0.40f;
            if (level() instanceof ServerLevel server) {
                server.sendParticles(ParticleTypes.END_ROD, getX(), getY() + 1.2, getZ(),
                    12, 0.65, 0.85, 0.65, 0.025);
            }
        }
        boolean accepted = super.hurt(source, amount);
        if (accepted) {
            healthRegenDelay = 60;
            armorReserve = Math.max(0.0, armorReserve - 0.5);
            var armorAttribute = getAttribute(Attributes.ARMOR);
            if (armorAttribute != null) armorAttribute.setBaseValue(armorReserve);
        }
        if (accepted && !level().isClientSide() && isAlive()) {
            if (consecutiveHitWindow == 0) consecutiveHits = 0;
            consecutiveHits++;
            consecutiveHitWindow = 160;
            if (consecutiveHits >= 3 && shieldCooldown == 0 && shieldTicks == 0
                    && !isDragonEncounterActive()) {
                activateDefensiveShield();
            }
            // A melee rush triggers a controlled shockwave counterattack.
            if (source.getEntity() instanceof LivingEntity attacker
                    && attacker.isAlive() && attacker.distanceToSqr(this) <= 36.0
                    && counterattackCooldown == 0 && !isDragonEncounterActive()) {
                performCounterattack(attacker);
            }
            if (level() instanceof ServerLevel server) {
                server.sendParticles(ParticleTypes.DAMAGE_INDICATOR,
                    getX(), getY() + getBbHeight() * 0.65, getZ(),
                    9, 0.35, 0.55, 0.35, 0.06);
            }
            if (hitFeedbackTicks == 0) {
                triggerAnim("actions", amount >= 14.0f ? "stagger" : "hurt");
                hitFeedbackTicks = 8;
            }
            // Only successful hits trigger evasion; subsequent hits still deal damage.
            if (defensiveTeleportCooldown == 0 && !dragonPhaseStarted) {
                defensiveTeleportCooldown = DEFENSIVE_TELEPORT_TICKS;
                LivingEntity attacker = source.getEntity() instanceof LivingEntity living
                    ? living : getTarget();
                if (attacker != null && attacker.isAlive()) {
                    if (cloneSwapCooldown == 0 && !isDragonEncounterActive() && swapWithClone(attacker)) {
                        defensiveTeleportCooldown = DEFENSIVE_TELEPORT_TICKS;
                    } else if (teleportAwayFrom(attacker)) {
                        comboRemaining = 0;
                        attackCooldown = Math.max(attackCooldown, 8);
                    }
                }
            }
        }
        return accepted;
    }

    private void beginSummoning(boolean withers) {
        pendingWithers = withers;
        summonWindup = SUMMON_WINDUP_TICKS;
        // Apply the long cooldown only after a successful spawn.
        summonCooldown = SUMMON_WINDUP_TICKS + 1;
        triggerAnim("actions", withers ? "summon_withers" : "summon_wardens");
        if (level() instanceof ServerLevel server) {
            server.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, getX(), getY() + 1.5, getZ(),
                24, 1.0, 0.8, 1.0, 0.04);
        }
    }

    private void finishSummoning() {
        if (!(level() instanceof ServerLevel server) || !isAlive()) return;
        LivingEntity target = getTarget();
        if (target == null || !target.isAlive()) {
            summonCooldown = SUMMON_RETRY_TICKS;
            return;
        }

        int remaining = pendingWithers ? MAX_WITHERS - summonedWithers.size()
                                      : MAX_WARDENS - summonedWardens.size();
        int created = 0;
        for (int i = 0; i < Math.min(2, remaining); i++) {
            Vec3 spot = findSummonLocation(server, target, pendingWithers, i);
            if (spot == null) continue;
            if (pendingWithers) {
                WitherBoss wither = EntityType.WITHER.create(server);
                if (wither == null) continue;
                wither.moveTo(spot.x, spot.y, spot.z, random.nextFloat() * 360.0f, 0.0f);
                if (!server.noCollision(wither)) continue;
                wither.setPersistenceRequired();
                wither.setTarget(target);
                if (server.addFreshEntity(wither)) {
                    summonedWithers.add(wither);
                    created++;
                }
            } else {
                Warden warden = EntityType.WARDEN.create(server);
                if (warden == null) continue;
                warden.moveTo(spot.x, spot.y, spot.z, random.nextFloat() * 360.0f, 0.0f);
                if (!server.noCollision(warden)) continue;
                warden.setPersistenceRequired();
                // Disable vanilla Warden Brain: otherwise DIG can despawn it despite
                // anger refresh. v2.03 runs a dedicated summon combat controller.
                warden.setNoAi(true);
                warden.setTarget(target);
                // Anger, rather than just setTarget, prevents the Warden from
                // returning to its idle dig/despawn activity during this encounter.
                warden.increaseAngerAt(target);
                if (server.addFreshEntity(warden)) {
                    summonedWardens.add(warden);
                    created++;
                }
            }
            server.sendParticles(ParticleTypes.PORTAL, spot.x, spot.y + 1.0, spot.z,
                65, 0.9, 1.1, 0.9, 0.1);
            server.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, spot.x, spot.y + 0.8, spot.z,
                28, 0.5, 0.7, 0.5, 0.025);
        }
        if (created > 0) {
            summonCooldown = SUMMON_COOLDOWN_TICKS;
            summonNextWithers = !pendingWithers;
        } else {
            // Do not silently burn 75 seconds when no valid position was found.
            summonCooldown = SUMMON_RETRY_TICKS;
        }
    }

    private Vec3 findSummonLocation(ServerLevel server, LivingEntity target,
                                   boolean withers, int index) {
        // Test multiple angles and heights, with both player-relative and boss-relative
        // candidates. Validate the entity's actual collision box before spawning.
        for (int attempt = 0; attempt < 32; attempt++) {
            double angle = (index * Math.PI) + attempt * 2.399963229728653;
            double radius = 5.0 + (attempt % 5) * 1.75;
            double originX = attempt % 2 == 0 ? getX() : target.getX();
            double originZ = attempt % 2 == 0 ? getZ() : target.getZ();
            double x = originX + Math.cos(angle) * radius;
            double z = originZ + Math.sin(angle) * radius;
            double baseY = attempt % 2 == 0 ? getY() : target.getY();

            if (withers) {
                // Withers can hover: don't require a solid floor.
                for (int dy = 4; dy >= -2; dy--) {
                    double y = baseY + dy;
                    WitherBoss probe = EntityType.WITHER.create(server);
                    if (probe == null) return null;
                    probe.moveTo(x, y, z, 0, 0);
                    if (server.noCollision(probe)) return new Vec3(x, y, z);
                }
            } else {
                for (int dy = 5; dy >= -9; dy--) {
                    double y = Math.floor(baseY + dy);
                    BlockPos floor = BlockPos.containing(x, y - 1, z);
                    if (!server.getBlockState(floor).isFaceSturdy(server, floor, Direction.UP))
                        continue;
                    Warden probe = EntityType.WARDEN.create(server);
                    if (probe == null) return null;
                    probe.moveTo(x, y, z, 0, 0);
                    if (server.noCollision(probe)) return new Vec3(x, y, z);
                }
            }
        }
        return null;
    }

    private void maintainSummonedReinforcements() {
        summonedWithers.removeIf(e -> !e.isAlive() || e.isRemoved());
        summonedWardens.removeIf(e -> !e.isAlive() || e.isRemoved());
        LivingEntity target = getTarget();
        if (target == null || !target.isAlive()
                || (target instanceof Player player && (player.isCreative() || player.isSpectator())))
            return;
        for (WitherBoss wither : summonedWithers) {
            if (wither.level() == level() && wither.distanceToSqr(target) < 96 * 96) {
                wither.setTarget(target);
                // Do not allow the Wither to remain focused on Herobrine.
                if (wither.getTarget() == this) wither.setTarget(target);
            }
        }
        for (Warden warden : summonedWardens) {
            if (warden.level() == level() && warden.distanceToSqr(target) < 96 * 96) {
                warden.setNoAi(true); // Hard guarantee: vanilla DIG cannot run.
                tickWardenAlly(warden, target);
            }
        }
    }

    private void activateDefensiveShield() {
        shieldTicks = SHIELD_DURATION_TICKS;
        shieldCooldown = SHIELD_COOLDOWN_TICKS;
        consecutiveHits = 0;
        consecutiveHitWindow = 0;
        if (level() instanceof ServerLevel server) {
            server.sendParticles(ParticleTypes.END_ROD, getX(), getY() + 1.2, getZ(),
                65, 1.0, 1.1, 1.0, 0.09);
            server.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, getX(), getY() + 1.0, getZ(),
                30, 0.8, 0.8, 0.8, 0.03);
        }
    }

    private void tickDefensiveShield() {
        if (!(level() instanceof ServerLevel server)) return;
        // Lightweight shield particles, no permanent blocks or new textures.
        if (tickCount % 5 == 0) {
            for (int i = 0; i < 12; i++) {
                double angle = (i * Math.PI / 6.0) + tickCount * 0.045;
                double y = getY() + 0.35 + (i % 4) * 0.55;
                server.sendParticles(ParticleTypes.END_ROD,
                    getX() + Math.cos(angle) * 1.35, y,
                    getZ() + Math.sin(angle) * 1.35,
                    1, 0.015, 0.015, 0.015, 0.0);
            }
        }
        // Reflect player-fired projectiles only, with a bounded speed and a
        // short per-projectile exclusion via its owner becoming Herobrine.
        for (Projectile projectile : server.getEntitiesOfClass(Projectile.class,
                getBoundingBox().inflate(2.2), e -> e.isAlive() && e.getOwner() instanceof Player)) {
            Vec3 velocity = projectile.getDeltaMovement();
            if (velocity.lengthSqr() < 0.005) continue;
            Vec3 away = projectile.position().subtract(position());
            if (away.lengthSqr() < 0.01) away = velocity.reverse();
            away = away.normalize();
            Vec3 reflected = away.scale(Math.min(2.0, Math.max(0.6, velocity.length())));
            projectile.setOwner(this);
            projectile.setDeltaMovement(reflected);
            projectile.hasImpulse = true;
            projectile.setPos(projectile.getX() + away.x * 0.5,
                projectile.getY() + away.y * 0.5,
                projectile.getZ() + away.z * 0.5);
            deflectedProjectiles++;
            server.sendParticles(ParticleTypes.CRIT,
                projectile.getX(), projectile.getY(), projectile.getZ(),
                12, 0.2, 0.2, 0.2, 0.08);
        }
    }

    private void performCounterattack(LivingEntity attacker) {
        counterattackCooldown = 160;
        Vec3 away = attacker.position().subtract(position()).multiply(1, 0, 1);
        if (away.lengthSqr() < 0.01) away = new Vec3(1, 0, 0);
        away = away.normalize();
        // A counterattack should not kill a player instantly through modded armor.
        com.herobrineboss.combat.CombatEvents.herobrineStrike(attacker, damageSources().mobAttack(this), 6.0f);
        attacker.push(away.x * 1.2, 0.45, away.z * 1.2);
        attacker.hurtMarked = true;
        triggerAnim("actions", "knockback");
        if (level() instanceof ServerLevel server) {
            server.sendParticles(ParticleTypes.SWEEP_ATTACK,
                attacker.getX(), attacker.getY() + 1, attacker.getZ(),
                8, 0.5, 0.4, 0.5, 0.01);
        }
    }

    /** v2.04 adaptive combat: evaluate the immediate fight every 10 ticks.
     * Keep all responses bounded and preserve the 12–20-block combat preference.
     */
    private void tickAdaptiveCombat(LivingEntity target) {
        if (adaptiveCheckCooldown > 0) return;
        adaptiveCheckCooldown = 10;
        if (target != observedTarget) {
            observedTarget = target;
            observedTargetHealth = target.getHealth();
            lastObservedTargetPos = target.position();
            targetStillTicks = 0;
            lostSightTicks = 0;
        }
        if (hasLineOfSight(target)) lostSightTicks = 0;
        else lostSightTicks = Math.min(200, lostSightTicks + 10);

        // Healing detection: short burst of attack pressure, not a permanent buff.
        if (target.getHealth() > observedTargetHealth + 1.0f)
            pressureTicks = Math.max(pressureTicks, 80);
        observedTargetHealth = target.getHealth();

        if (target.position().distanceToSqr(lastObservedTargetPos) < 0.4)
            targetStillTicks = Math.min(200, targetStillTicks + 10);
        else targetStillTicks = 0;
        lastObservedTargetPos = target.position();

        // Look for incoming projectiles. Avoid only when actually nearby, and
        // strafe rather than teleport away from the whole encounter.
        AABB danger = getBoundingBox().inflate(9.0);
        for (Projectile projectile : level().getEntitiesOfClass(Projectile.class, danger,
                e -> e.isAlive() && e.getOwner() != this)) {
            Vec3 velocity = projectile.getDeltaMovement();
            Vec3 toBoss = position().subtract(projectile.position());
            if (velocity.lengthSqr() > 0.01 && velocity.dot(toBoss) > 0) {
                evasiveStrafeTicks = 35;
                strafeDirection = random.nextBoolean() ? 1 : -1;
                break;
            }
        }

        // Multiplayer target selection: prioritize a close, visible attacker,
        // but use a cooldown to prevent rapid target flickering.
        if (targetSwitchCooldown == 0 && level() instanceof ServerLevel server) {
            Player best = null;
            double bestScore = Double.NEGATIVE_INFINITY;
            for (Player candidate : server.getEntitiesOfClass(Player.class,
                    getBoundingBox().inflate(DETECTION_RADIUS),
                    pl -> pl.isAlive() && !pl.isCreative() && !pl.isSpectator())) {
                double range = Math.sqrt(distanceToSqr(candidate));
                double score = 100.0 - range;
                if (hasLineOfSight(candidate)) score += 25.0;
                if (candidate == target) score += 18.0; // sticky targeting
                if (candidate.distanceToSqr(this) < 64) score += 12.0;
                if (score > bestScore) { best = candidate; bestScore = score; }
            }
            if (best != null && best != target) {
                setTarget(best);
                observedTarget = null;
                targetSwitchCooldown = 60;
            } else targetSwitchCooldown = 30;
        }
    }

    private Vec3 predictedTargetPoint(LivingEntity target, double ticksAhead) {
        // Cap prediction so movement boosts don't lead shots absurdly far away.
        Vec3 velocity = target.getDeltaMovement();
        double x = Math.max(-0.5, Math.min(0.5, velocity.x));
        double y = Math.max(-0.2, Math.min(0.2, velocity.y));
        double z = Math.max(-0.5, Math.min(0.5, velocity.z));
        return target.getEyePosition().add(x * ticksAhead, y * ticksAhead, z * ticksAhead);
    }

    private void chooseBedrockAttack(LivingEntity target) {
        bedrockCooldown = 75 + random.nextInt(45);
        int choice = random.nextInt(5);
        switch (choice) {
            case 0 -> { // Telegraph a lifted block, then throw it.
                heldBlockTicks = 20;
                spawnHeldBlock();
                triggerAnim("actions", "bedrock_lift");
            }
            case 1 -> { // Rapid five-projectile barrage.
                barrageShots = 5;
                barrageDelay = 7;
                triggerAnim("actions", "bedrock_barrage");
            }
            case 2 -> {
                triggerAnim("actions", "terrain_break");
                shatterTerrain(target);
            }
            case 3 -> { // A defensive wall is also available when three players surround him.
                if (wallCooldown == 0) raiseWall(target);
                else { launchTelekineticVolley(target); triggerAnim("actions", "bedrock_throw"); }
            }
            default -> { launchTelekineticVolley(target); triggerAnim("actions", "bedrock_throw"); }
        }
    }

    /** Configure a BlockDisplay through its public entity serialization API.
     * The full tag is retained to avoid overwriting the entity's other fields.
     */
    private static void setBedrockDisplayState(Display.BlockDisplay display) {
        CompoundTag tag = new CompoundTag();
        display.saveWithoutId(tag);
        tag.put("block_state", NbtUtils.writeBlockState(Blocks.BEDROCK.defaultBlockState()));
        display.load(tag);
    }

    private void spawnHeldBlock() {
        if (!(level() instanceof ServerLevel server)) return;
        removeHeldBlock();
        heldBlock = new Display.BlockDisplay(EntityType.BLOCK_DISPLAY, server);
        setBedrockDisplayState(heldBlock);
        heldBlock.setPos(getX() + 1.0, getY() + 2.2, getZ());
        server.addFreshEntity(heldBlock);
    }

    private void removeHeldBlock() {
        if (heldBlock != null) heldBlock.discard();
        heldBlock = null;
    }

    // v2.033: each telekinetic throw launches a randomized 3–7-block volley.
    // Existing rapid barrage and mounted dragon projectiles remain unchanged.
    private void launchTelekineticVolley(LivingEntity target) {
        if (!(level() instanceof ServerLevel server) || target == null || !target.isAlive()) return;
        int count = 3 + random.nextInt(5);
        Vec3 origin = position().add(0, getBbHeight() * 0.8, 0);
        Vec3 forward = predictedTargetPoint(target, 6.0).subtract(origin);
        if (forward.lengthSqr() < 0.001) return;
        forward = forward.normalize();
        Vec3 side = new Vec3(-forward.z, 0, forward.x);
        if (side.lengthSqr() < 0.001) side = new Vec3(1, 0, 0);
        side = side.normalize();
        // Wide fan: each projectile starts separated AND travels along a different
        // trajectory. No convergence into the same target point mid-flight.
        for (int i = 0; i < count; i++) {
            double lane = i - (count - 1) / 2.0;
            double fan = lane / Math.max(1.0, (count - 1) / 2.0);
            Vec3 spawn = origin.add(side.scale(lane * 1.65))
                .add(0, Math.sin(i * 1.7) * 0.8 + 0.4, 0);
            Vec3 aimPoint = predictedTargetPoint(target, 6.0)
                .add(side.scale(fan * 6.0))
                .add(0, Math.cos(i * 2.1) * 1.25 - 0.3, 0);
            Vec3 velocity = aimPoint.subtract(spawn);
            if (velocity.lengthSqr() < 0.001) continue;
            Display.BlockDisplay visual = new Display.BlockDisplay(EntityType.BLOCK_DISPLAY, server);
            setBedrockDisplayState(visual);
            visual.setPos(spawn.x, spawn.y, spawn.z);
            if (server.addFreshEntity(visual))
                shots.add(new BedrockShot(visual, velocity.normalize().scale(0.85), 45));
        }
    }

    private void launchBedrock(LivingEntity target) {
        if (!(level() instanceof ServerLevel server)) return;
        Display.BlockDisplay visual = new Display.BlockDisplay(EntityType.BLOCK_DISPLAY, server);
        setBedrockDisplayState(visual);
        Vec3 origin = position().add(0, getBbHeight() * 0.8, 0);
        Vec3 aim = predictedTargetPoint(target, 6.0).subtract(origin);
        if (aim.lengthSqr() < 0.001) return;
        visual.setPos(origin.x, origin.y, origin.z);
        server.addFreshEntity(visual);
        shots.add(new BedrockShot(visual, aim.normalize().scale(0.85), 45));
    }

    private void tickBedrockVisuals() {
        if (!(level() instanceof ServerLevel server)) return;
        if (heldBlock != null) {
            if (heldBlock.isRemoved()) heldBlock = null;
            else heldBlock.setPos(getX() + 1.0, getY() + 2.2, getZ());
        }
        Iterator<BedrockShot> iter = shots.iterator();
        while (iter.hasNext()) {
            BedrockShot shot = iter.next();
            Display.BlockDisplay display = shot.display;
            Vec3 next = display.position().add(shot.velocity);
            AABB hitbox = new AABB(next.x - 0.45, next.y - 0.45, next.z - 0.45,
                                   next.x + 0.45, next.y + 0.45, next.z + 0.45);
            LivingEntity victim = server.getEntitiesOfClass(LivingEntity.class, hitbox,
                e -> e != this && e.isAlive() && e instanceof Player p && !p.isCreative() && !p.isSpectator())
                .stream().findFirst().orElse(null);
            boolean blocked = !server.getBlockState(BlockPos.containing(next)).getCollisionShape(server, BlockPos.containing(next)).isEmpty();
            if (victim != null) {
                com.herobrineboss.combat.CombatEvents.herobrineStrike(victim, damageSources().mobProjectile(this, this), 15.0f);
            }
            if (victim != null || blocked || --shot.lifetime <= 0 || display.isRemoved()) {
                explodeBedrock(next);
                server.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.BEDROCK.defaultBlockState()),
                    next.x, next.y, next.z, 25, 0.6, 0.6, 0.6, 0.11);
                display.discard();
                iter.remove();
            } else display.setPos(next.x, next.y, next.z);
        }
        Iterator<TemporaryWallBlock> walls = wallBlocks.iterator();
        while (walls.hasNext()) {
            TemporaryWallBlock wall = walls.next();
            if (--wall.lifetime <= 0) {
                if (server.getBlockState(wall.pos).is(Blocks.BEDROCK)) server.setBlock(wall.pos, wall.previous, 3);
                walls.remove();
            }
        }
    }

    private int nearbyThreatCount() {
        return level().getEntitiesOfClass(Player.class, getBoundingBox().inflate(12),
            p -> p.isAlive() && !p.isCreative() && !p.isSpectator()).size();
    }

    private void raiseWall(LivingEntity target) {
        if (!(level() instanceof ServerLevel server)) return;
        wallCooldown = 260;
        triggerAnim("actions", "bedrock_wall");
        // Temporary barrier between Herobrine and his target; never overwrite occupied blocks.
        Vec3 toward = target.position().subtract(position()).multiply(1, 0, 1);
        if (toward.lengthSqr() < 0.01) return;
        Vec3 center = position().add(toward.normalize().scale(3.0));
        Vec3 side = new Vec3(-toward.z, 0, toward.x).normalize();
        BlockPos centerPos = BlockPos.containing(center);
        for (int dx = -2; dx <= 2; dx++) {
            for (int dy = 0; dy < 3; dy++) {
                BlockPos pos = BlockPos.containing(centerPos.getX() + side.x * dx, centerPos.getY() + dy, centerPos.getZ() + side.z * dx);
                BlockState old = server.getBlockState(pos);
                if (!old.isAir() || !server.getFluidState(pos).isEmpty()) continue;
                server.setBlock(pos, Blocks.BEDROCK.defaultBlockState(), 3);
                wallBlocks.add(new TemporaryWallBlock(pos, old, 100));
            }
        }
    }

    /** Destruction gate: no protected blocks, block entities, unloaded chunks or liquids. */
    private boolean canBreakBattlefieldBlock(ServerLevel server, BlockPos pos) {
        if (!server.getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING)
                || !server.hasChunkAt(pos) || !server.getWorldBorder().isWithinBounds(pos)) return false;
        BlockState state = server.getBlockState(pos);
        if (state.isAir() || state.hasBlockEntity() || !server.getFluidState(pos).isEmpty()
                || state.is(Blocks.BEDROCK)) return false;
        float hardness = state.getDestroySpeed(server, pos);
        return hardness >= 0 && hardness <= MAX_DESTRUCTIBLE_HARDNESS;
    }

    private boolean breakBattlefieldBlock(ServerLevel server, BlockPos pos) {
        if (!canBreakBattlefieldBlock(server, pos)) return false;
        BlockState state = server.getBlockState(pos);
        if (!server.destroyBlock(pos, false, this)) return false;
        server.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, state),
            pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5,
            8, 0.3, 0.3, 0.3, 0.08);
        return true;
    }

    private void shatterTerrain(LivingEntity target) {
        if (!(level() instanceof ServerLevel server)) return;
        BlockPos base = target.blockPosition().below();
        for (int dx = -2; dx <= 2; dx++) for (int dz = -2; dz <= 2; dz++) {
            if (dx * dx + dz * dz > 5) continue;
            breakBattlefieldBlock(server, base.offset(dx, 0, dz));
        }
    }

    /** Ground fissure: a 12-block path with a shallow, irregular split. */
    private void eruptFissure(LivingEntity target) {
        if (!(level() instanceof ServerLevel server)) return;
        fissureCooldown = 260;
        triggerAnim("actions", "terrain_break");
        Vec3 horizontal = target.position().subtract(position()).multiply(1, 0, 1);
        if (horizontal.lengthSqr() < 0.01) return;
        Vec3 direction = horizontal.normalize();
        Vec3 sideways = new Vec3(-direction.z, 0, direction.x);
        int broken = 0;
        for (int step = 2; step <= 13 && broken < MAX_TERRAIN_BLOCKS_PER_ATTACK; step++) {
            Vec3 point = position().add(direction.scale(step));
            BlockPos at = BlockPos.containing(point.x, target.getY(), point.z);
            BlockPos ground = server.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, at).below();
            for (int width = -1; width <= 1; width++) {
                if (width != 0 && random.nextBoolean()) continue;
                BlockPos pos = ground.offset((int)Math.round(sideways.x * width), 0,
                    (int)Math.round(sideways.z * width));
                if (breakBattlefieldBlock(server, pos)) broken++;
                if (broken >= MAX_TERRAIN_BLOCKS_PER_ATTACK) break;
            }
            if (step % 3 == 0) server.sendParticles(ParticleTypes.LARGE_SMOKE,
                ground.getX() + 0.5, ground.getY() + 1.1, ground.getZ() + 0.5,
                8, 0.5, 0.2, 0.5, 0.03);
        }
        for (Player player : server.getEntitiesOfClass(Player.class,
                getBoundingBox().inflate(16), p -> p.isAlive() && !p.isCreative() && !p.isSpectator())) {
            if (player.onGround() && player.distanceToSqr(target) < 36) {
                com.herobrineboss.combat.CombatEvents.herobrineStrike(player, damageSources().mobAttack(this), 5.0f);
                player.push(0, 0.35, 0);
            }
        }
    }

    /** Localized collapse beneath the player's feet, not an unbounded explosion. */
    private void collapseGround(LivingEntity target) {
        if (!(level() instanceof ServerLevel server)) return;
        collapseCooldown = 340;
        triggerAnim("actions", "terrain_break");
        BlockPos center = target.blockPosition().below();
        int broken = 0;
        for (int dy = 0; dy >= -1; dy--) for (int dx = -2; dx <= 2; dx++)
            for (int dz = -2; dz <= 2; dz++) {
                if (dx * dx + dz * dz > 5 || random.nextFloat() > 0.7f) continue;
                if (breakBattlefieldBlock(server, center.offset(dx, dy, dz))) broken++;
                if (broken >= MAX_TERRAIN_BLOCKS_PER_ATTACK) return;
            }
    }

    private void groundSlam(LivingEntity target) {
        if (!(level() instanceof ServerLevel server)) return;
        slamCooldown = 160;
        triggerAnim("actions", "ground_slam");
        for (Player p : server.getEntitiesOfClass(Player.class, getBoundingBox().inflate(5),
                pl -> pl.isAlive() && !pl.isCreative() && !pl.isSpectator())) {
            com.herobrineboss.combat.CombatEvents.herobrineStrike(p, damageSources().mobAttack(this), 10.0f);
            Vec3 away = p.position().subtract(position()).multiply(1, 0, 1).normalize();
            p.push(away.x * 1.5, 0.6, away.z * 1.5);
        }
        // Fracture a narrow ring around the impact, leaving Herobrine's feet intact.
        int broken = 0;
        for (int angleStep = 0; angleStep < 24 && broken < MAX_TERRAIN_BLOCKS_PER_ATTACK; angleStep++) {
            double angle = angleStep * (Math.PI * 2 / 24.0);
            int radius = 3 + (angleStep % 2);
            BlockPos sample = BlockPos.containing(getX() + Math.cos(angle) * radius,
                getY(), getZ() + Math.sin(angle) * radius);
            BlockPos ground = server.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, sample).below();
            if (breakBattlefieldBlock(server, ground)) broken++;
        }
        server.sendParticles(ParticleTypes.EXPLOSION, getX(), getY() + 0.3, getZ(), 12, 2, 0.2, 2, 0.1);
    }

    private static final class BedrockShot {
        final Display.BlockDisplay display;
        final Vec3 velocity;
        int lifetime;
        BedrockShot(Display.BlockDisplay display, Vec3 velocity, int lifetime) {
            this.display = display; this.velocity = velocity; this.lifetime = lifetime;
        }
    }
    private static final class TemporaryWallBlock {
        final BlockPos pos;
        final BlockState previous;
        int lifetime;
        TemporaryWallBlock(BlockPos pos, BlockState previous, int lifetime) {
            this.pos = pos; this.previous = previous; this.lifetime = lifetime;
        }
    }

    @Override public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        if (!(this instanceof HerobrineCloneEntity)) bossBar.addPlayer(player);
    }

    @Override public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        if (!(this instanceof HerobrineCloneEntity)) bossBar.removePlayer(player);
    }

    @Override public void remove(RemovalReason reason) {
        if (!level().isClientSide() && level() instanceof ServerLevel server) {
            bossBar.removeAllPlayers();
            removeHeldBlock();
            if (isPassenger()) stopRiding();
            // Dragon remains as a vanilla boss if Herobrine is forcibly removed.
            for (BedrockShot shot : shots) shot.display.discard();
            shots.clear();
            for (TemporaryWallBlock wall : wallBlocks) {
                if (server.getBlockState(wall.pos).is(Blocks.BEDROCK)) server.setBlock(wall.pos, wall.previous, 3);
            }
            wallBlocks.clear();
        }
        super.remove(reason);
    }

    /** The preferred 12–20-block range is suspended only while our dragon lives.
     *  When the dragon dies, beginFinalPhase() clears the reference and restores
     *  normal ranged positioning automatically.
     */
    private boolean isDragonEncounterActive() {
        return dragonPhaseStarted && !finalPhase && summonedDragon != null
            && summonedDragon.isAlive() && !summonedDragon.isRemoved();
    }

    private void pursueInAir(LivingEntity target) {
        setNoGravity(true);
        getNavigation().stop();
        Vec3 offset = position().subtract(target.position()).multiply(1, 0, 1);
        if (offset.lengthSqr() < 0.01) offset = new Vec3(1, 0, 0);
        Vec3 outward = offset.normalize();
        Vec3 lateral = new Vec3(-outward.z, 0, outward.x);
        if (strafeChangeCooldown == 0) {
            strafeChangeCooldown = 35 + random.nextInt(35);
            strafeDirection = random.nextBoolean() ? 1 : -1;
        }
        double range = Math.sqrt(offset.lengthSqr());
        double radial = isDragonEncounterActive() ? 0.0
            : range < 9.0 ? 0.25
            : range > MAX_RANGED_DISTANCE ? -0.40 : 0.0;
        double desiredY = target.getY() + 4.0 + Math.sin(tickCount * 0.045) * 1.4;
        double vertical = Math.max(-0.20, Math.min(0.20, (desiredY - getY()) * 0.09));
        Vec3 desired = outward.scale(radial)
            .add(lateral.scale(strafeDirection * (evasiveStrafeTicks > 0 ? 0.35 : 0.16)))
            .add(0, vertical, 0);
        Vec3 next = getDeltaMovement().scale(0.55).add(desired.scale(0.45));
        if (level().noCollision(this, getBoundingBox().move(next))) setDeltaMovement(next);
        else setDeltaMovement(Vec3.ZERO);
        hasImpulse = true;
    }

    private void pursueOnGround(LivingEntity target) {
        double range = Math.sqrt(distanceToSqr(target));
        if (isDragonEncounterActive()) {
            getNavigation().stop();
            return;
        }
        if (range < 7.0) {
            Vec3 away = position().subtract(target.position()).multiply(1, 0, 1);
            if (away.lengthSqr() > 0.01) {
                Vec3 retreat = position().add(away.normalize().scale(4.0));
                getNavigation().moveTo(retreat.x, retreat.y, retreat.z, 1.3);
            }
        } else if (range > MAX_RANGED_DISTANCE) {
            getNavigation().moveTo(target, 1.2);
        } else if (!hasLineOfSight(target) && lostSightTicks > 20) {
            Vec3 to = target.position().subtract(position()).multiply(1, 0, 1);
            if (to.lengthSqr() > 0.01) {
                Vec3 flank = new Vec3(-to.z, 0, to.x).normalize().scale(strafeDirection * 5.0);
                Vec3 spot = position().add(flank);
                getNavigation().moveTo(spot.x, spot.y, spot.z, 1.2);
            }
        } else {
            getNavigation().stop();
        }
    }

    private boolean teleportAwayFrom(LivingEntity attacker) {
        if (!(level() instanceof ServerLevel server)) return false;
        Vec3 away = position().subtract(attacker.position()).multiply(1, 0, 1);
        if (away.lengthSqr() < 0.01) away = new Vec3(1, 0, 0);
        away = away.normalize();
        Vec3 old = position();
        for (int attempt = 0; attempt < 18; attempt++) {
            double distance = 12.0 + random.nextDouble() * 8.0;
            double angle = (random.nextDouble() - 0.5) * 1.5;
            Vec3 direction = new Vec3(
                away.x * Math.cos(angle) - away.z * Math.sin(angle),
                0,
                away.x * Math.sin(angle) + away.z * Math.cos(angle));
            double x = attacker.getX() + direction.x * distance;
            double z = attacker.getZ() + direction.z * distance;
            for (int dy = 4; dy >= -5; dy--) {
                double y = attacker.getY() + dy;
                BlockPos floor = BlockPos.containing(x, y - 0.1, z);
                if (!server.getBlockState(floor).isFaceSturdy(server, floor, Direction.UP)) continue;
                AABB box = getBoundingBox().move(x - getX(), y - getY(), z - getZ());
                if (!server.noCollision(this, box)) continue;
                server.sendParticles(ParticleTypes.REVERSE_PORTAL, old.x, old.y + 1, old.z,
                    30, 0.45, 0.8, 0.45, 0.06);
                triggerAnim("actions", "teleport_out");
                teleportTo(x, y, z);
                getNavigation().stop();
                stopFlight();
                server.sendParticles(ParticleTypes.PORTAL, x, y + 1, z,
                    35, 0.5, 0.8, 0.5, 0.08);
                triggerAnim("actions", "teleport_in");
                return true;
            }
        }
        return false;
    }

    private void explodeBedrock(Vec3 center) {
        if (!(level() instanceof ServerLevel server)) return;
        // Explosion strength 8. MOB interaction respects the mobGriefing gamerule;
        // NONE keeps the damage/blast while preserving terrain when disabled.
        boolean griefing = server.getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING);
        server.explode(this, center.x, center.y, center.z, 8.0f,
            griefing ? Level.ExplosionInteraction.MOB : Level.ExplosionInteraction.NONE);
    }

    private void fireEnergyBeam() {
        if (!(level() instanceof ServerLevel server) || !isAlive()
                || beamLockedDirection.lengthSqr() < 0.01) return;
        Vec3 start = getEyePosition();
        Vec3 end = start.add(beamLockedDirection.scale(36.0));
        HitResult blockHit = server.clip(new ClipContext(start, end,
            ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, this));
        if (blockHit.getType() != HitResult.Type.MISS) end = blockHit.getLocation();
        Vec3 delta = end.subtract(start);
        double length = delta.length();
        if (length < 0.01) return;
        Vec3 unit = delta.normalize();
        for (double d = 0; d <= length; d += 0.45) {
            Vec3 point = start.add(unit.scale(d));
            server.sendParticles(ParticleTypes.END_ROD, point.x, point.y, point.z,
                2, 0.08, 0.08, 0.08, 0.002);
            if (((int) (d * 10)) % 9 == 0)
                server.sendParticles(ParticleTypes.SOUL_FIRE_FLAME,
                    point.x, point.y, point.z, 1, 0.06, 0.06, 0.06, 0.001);
        }
        AABB region = new AABB(start, end).inflate(1.2);
        for (Player player : server.getEntitiesOfClass(Player.class, region,
                p -> p.isAlive() && !p.isCreative() && !p.isSpectator())) {
            if (player.getBoundingBox().inflate(0.5).clip(start, end).isPresent()) {
                com.herobrineboss.combat.CombatEvents.herobrineStrike(player, damageSources().magic(), 20.0f);
                Vec3 push = unit.multiply(1, 0, 1);
                player.push(push.x * 0.6, 0.3, push.z * 0.6);
            }
        }
    }

    private void stopFlight() {
        flying = false;
        entityData.set(FLYING, false);
        setNoGravity(false);
    }

    private boolean teleportNear(LivingEntity target) {
        if (!(level() instanceof ServerLevel server)) return false;
        Vec3 facing = target.getLookAngle().multiply(1, 0, 1);
        if (facing.lengthSqr() < 0.01) facing = new Vec3(1, 0, 0);
        facing = facing.normalize();
        // Try behind target first, then nearby alternatives, never inside blocks.
        for (int attempt = 0; attempt < 10; attempt++) {
            double angle = attempt == 0 ? 0 : random.nextDouble() * Math.PI * 2;
            Vec3 offset = attempt == 0 ? facing.scale(-2.5)
                : new Vec3(Math.cos(angle) * 3.0, 0, Math.sin(angle) * 3.0);
            double x = target.getX() + offset.x;
            double z = target.getZ() + offset.z;
            for (int dy = 2; dy >= -3; dy--) {
                double y = target.getY() + dy;
                BlockPos below = BlockPos.containing(x, y - 0.1, z);
                if (!server.getBlockState(below).isFaceSturdy(server, below, net.minecraft.core.Direction.UP)) continue;
                AABB candidate = getBoundingBox().move(x - getX(), y - getY(), z - getZ());
                if (!server.noCollision(this, candidate)) continue;
                teleportTo(x, y, z);
                triggerAnim("actions", "teleport_in");
                getNavigation().stop();
                return true;
            }
        }
        return false;
    }

    /** Lets clone flight use the existing synced Herobrine flight animations,
     * without enabling any of the boss's aerial combat or dragon logic.
     */
    protected void setCloneFlyingAnimation(boolean active) {
        entityData.set(FLYING, active);
    }

    @Override public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "locomotion", 4, state -> {
            if (entityData.get(FLYING)) return state.setAndContinue(state.isMoving() ? FLY_FORWARD : FLY_IDLE);
            if (!state.isMoving()) return state.setAndContinue(IDLE);
            return state.setAndContinue(getTarget() != null ? RUN : WALK);
        }));
        controllers.add(new AnimationController<>(this, "actions", 0, state -> software.bernie.geckolib.animation.PlayState.STOP)
            .triggerableAnim("melee", RawAnimation.begin().thenPlay("anim.herobrine.melee_attack"))
            .triggerableAnim("hurt", RawAnimation.begin().thenPlay("anim.herobrine.hurt"))
            .triggerableAnim("stagger", RawAnimation.begin().thenPlay("anim.herobrine.stagger"))
            .triggerableAnim("beam_charge", RawAnimation.begin().thenPlay("anim.herobrine.bedrock_hold"))
            .triggerableAnim("knockback", RawAnimation.begin().thenPlay("anim.herobrine.knockback_attack"))
            .triggerableAnim("teleport_out", RawAnimation.begin().thenPlay("anim.herobrine.teleport_out"))
            .triggerableAnim("teleport_in", RawAnimation.begin().thenPlay("anim.herobrine.teleport_in"))
            .triggerableAnim("bedrock_lift", RawAnimation.begin().thenPlay("anim.herobrine.bedrock_lift"))
            .triggerableAnim("bedrock_throw", RawAnimation.begin().thenPlay("anim.herobrine.bedrock_throw"))
            .triggerableAnim("bedrock_barrage", RawAnimation.begin().thenPlay("anim.herobrine.bedrock_barrage"))
            .triggerableAnim("bedrock_wall", RawAnimation.begin().thenPlay("anim.herobrine.bedrock_wall"))
            .triggerableAnim("terrain_break", RawAnimation.begin().thenPlay("anim.herobrine.terrain_break"))
            .triggerableAnim("ground_slam", RawAnimation.begin().thenPlay("anim.herobrine.ground_slam"))
            .triggerableAnim("summon_withers", RawAnimation.begin().thenPlay("anim.herobrine.summon_withers"))
            .triggerableAnim("summon_wardens", RawAnimation.begin().thenPlay("anim.herobrine.summon_wardens"))
            .triggerableAnim("summon_dragon", RawAnimation.begin().thenPlay("anim.herobrine.summon_dragon"))
            .triggerableAnim("dragon_mount", RawAnimation.begin().thenPlay("anim.herobrine.dragon_mount"))
            .triggerableAnim("dragon_riding_attack", RawAnimation.begin().thenPlay("anim.herobrine.dragon_riding_attack"))
            .triggerableAnim("dragon_dismount", RawAnimation.begin().thenPlay("anim.herobrine.dragon_dismount"))
            .triggerableAnim("final_phase_transform", RawAnimation.begin().thenPlay("anim.herobrine.final_phase_transform"))
            .triggerableAnim("death", RawAnimation.begin().thenPlay("anim.herobrine.death")));
    }

    @Override public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }
}
