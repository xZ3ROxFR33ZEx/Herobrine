package com.herobrineboss.item;

import net.minecraft.core.Holder;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;

/** Vanilla armor attributes/rendering with extra defenses implemented in CombatEvents. */
public class BedrockArmorItem extends ArmorItem {
    public BedrockArmorItem(Holder<ArmorMaterial> material, Type type, Properties properties) {
        super(material, type, properties);
    }
}
