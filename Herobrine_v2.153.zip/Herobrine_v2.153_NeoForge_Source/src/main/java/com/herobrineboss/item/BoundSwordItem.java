package com.herobrineboss.item;

import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.ChatFormatting;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.TooltipFlag;

/** Intrinsic powers: never stored as extractable enchantment data. Normal enchantments still work. */
public class BoundSwordItem extends SwordItem {
    public enum Kind { BEDROCK, CREATOR, CURSED }
    private final Kind kind;
    public BoundSwordItem(Kind kind, Tier tier, Item.Properties properties) {
        super(tier, properties);
        this.kind = kind;
    }
    public Kind kind() { return kind; }
    /** Vanilla enchanted glint for the two permanently imbued blades. */
    @Override public boolean isFoil(ItemStack stack) {
        return kind == Kind.CREATOR || kind == Kind.CURSED || super.isFoil(stack);
    }
    @Override public void appendHoverText(ItemStack stack, Item.TooltipContext context,
                                          List<Component> tooltip, TooltipFlag flag) {
        super.appendHoverText(stack, context, tooltip, flag);
        if (kind == Kind.CREATOR) {
            tooltip.add(Component.literal("Notch's Blessing").withStyle(ChatFormatting.GOLD));
            tooltip.add(Component.literal("Only the hand of creation may undo what creation has forsaken.")
                .withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC));
        } else if (kind == Kind.CURSED) {
            tooltip.add(Component.literal("Curse of Herobrine").withStyle(ChatFormatting.DARK_RED));
        }
    }
}
