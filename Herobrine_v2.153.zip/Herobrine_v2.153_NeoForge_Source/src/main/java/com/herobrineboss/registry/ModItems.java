package com.herobrineboss.registry;

import com.herobrineboss.HerobrineMod;
import net.minecraft.world.item.Item;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.component.Unbreakable;
import net.minecraft.world.item.ArmorItem;
import com.herobrineboss.item.BedrockArmorItem;
import com.herobrineboss.item.BoundSwordItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;
import net.neoforged.neoforge.registries.DeferredHolder;
import java.util.Map;
import java.util.List;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(HerobrineMod.MOD_ID);
    public static final DeferredRegister<ArmorMaterial> ARMOR_MATERIALS =
        DeferredRegister.create(Registries.ARMOR_MATERIAL, HerobrineMod.MOD_ID);
    public static final DeferredHolder<ArmorMaterial, ArmorMaterial> BEDROCK_MATERIAL =
        ARMOR_MATERIALS.register("bedrock", () -> new ArmorMaterial(
            Map.of(ArmorItem.Type.HELMET, 5, ArmorItem.Type.CHESTPLATE, 15,
                   ArmorItem.Type.LEGGINGS, 10, ArmorItem.Type.BOOTS, 5,
                   ArmorItem.Type.BODY, 15),
            15, SoundEvents.ARMOR_EQUIP_NETHERITE,
            () -> Ingredient.of(Items.NETHERITE_INGOT),
            List.of(new ArmorMaterial.Layer(ResourceLocation.fromNamespaceAndPath(HerobrineMod.MOD_ID, "bedrock"))),
            5.0F, 0.15F));
    // Minecraft 1.21.1: 1 player base damage + 4 Netherite tier bonus + 53 = 58.
    // Base player attack speed 4.0 + attribute modifier 1.8 = 5.8.
    public static final DeferredItem<SwordItem> BEDROCK_SWORD = ITEMS.register("bedrock_sword",
        () -> new BoundSwordItem(BoundSwordItem.Kind.BEDROCK, Tiers.NETHERITE, new Item.Properties()
            .attributes(SwordItem.createAttributes(Tiers.NETHERITE, 53, 1.8f))
            .fireResistant()
            .component(DataComponents.UNBREAKABLE, new Unbreakable(true))));
    // Creator's Blade: 1 player base damage + 2 Iron tier bonus + 47 = 50.
    // Base player attack speed 4.0 + attribute modifier 1.0 = 5.0.
    // Its permanent enchantments and boss-specific properties will be implemented later.
    public static final DeferredItem<SwordItem> CREATORS_BLADE = ITEMS.register("creators_blade",
        () -> new BoundSwordItem(BoundSwordItem.Kind.CREATOR, Tiers.IRON, new Item.Properties()
            .attributes(SwordItem.createAttributes(Tiers.IRON, 47, 1.0f))
            .component(DataComponents.UNBREAKABLE, new Unbreakable(true))));

    // Separate registry item: only the unique boss/void drop carries the curse.
    public static final DeferredItem<SwordItem> CURSED_BEDROCK_SWORD = ITEMS.register("cursed_bedrock_sword",
        () -> new BoundSwordItem(BoundSwordItem.Kind.CURSED, Tiers.NETHERITE, new Item.Properties()
            .attributes(SwordItem.createAttributes(Tiers.NETHERITE, 53, 1.8f))
            .fireResistant().component(DataComponents.UNBREAKABLE, new Unbreakable(true))));

    public static final DeferredItem<ArmorItem> BEDROCK_HELMET = ITEMS.register("bedrock_helmet",
        () -> new BedrockArmorItem(BEDROCK_MATERIAL, ArmorItem.Type.HELMET, new Item.Properties().fireResistant().durability(407)
            .component(DataComponents.UNBREAKABLE, new Unbreakable(true))));
    public static final DeferredItem<ArmorItem> BEDROCK_CHESTPLATE = ITEMS.register("bedrock_chestplate",
        () -> new BedrockArmorItem(BEDROCK_MATERIAL, ArmorItem.Type.CHESTPLATE, new Item.Properties().fireResistant().durability(592)
            .component(DataComponents.UNBREAKABLE, new Unbreakable(true))));
    public static final DeferredItem<ArmorItem> BEDROCK_LEGGINGS = ITEMS.register("bedrock_leggings",
        () -> new BedrockArmorItem(BEDROCK_MATERIAL, ArmorItem.Type.LEGGINGS, new Item.Properties().fireResistant().durability(555)
            .component(DataComponents.UNBREAKABLE, new Unbreakable(true))));
    public static final DeferredItem<ArmorItem> BEDROCK_BOOTS = ITEMS.register("bedrock_boots",
        () -> new BedrockArmorItem(BEDROCK_MATERIAL, ArmorItem.Type.BOOTS, new Item.Properties().fireResistant().durability(481)
            .component(DataComponents.UNBREAKABLE, new Unbreakable(true))));
    private ModItems() {}
}
