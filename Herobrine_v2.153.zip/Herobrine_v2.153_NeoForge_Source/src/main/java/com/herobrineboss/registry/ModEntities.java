package com.herobrineboss.registry;

import com.herobrineboss.HerobrineMod;
import com.herobrineboss.entity.HerobrineEntity;
import com.herobrineboss.entity.HerobrineCloneEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES = DeferredRegister.create(Registries.ENTITY_TYPE, HerobrineMod.MOD_ID);
    public static final DeferredHolder<EntityType<?>, EntityType<HerobrineEntity>> HEROBRINE = ENTITY_TYPES.register("herobrine",
        () -> EntityType.Builder.of(HerobrineEntity::new, MobCategory.MONSTER)
            .sized(0.6f, 1.95f).clientTrackingRange(10).build("herobrine:herobrine"));
    public static final DeferredHolder<EntityType<?>, EntityType<HerobrineCloneEntity>> HEROBRINE_CLONE = ENTITY_TYPES.register("herobrine_clone",
        () -> EntityType.Builder.of(HerobrineCloneEntity::new, MobCategory.MONSTER)
            .sized(0.6f, 1.95f).clientTrackingRange(10).build("herobrine:herobrine_clone"));
    private ModEntities() {}
}
