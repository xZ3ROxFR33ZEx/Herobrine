package com.herobrineboss.client;

import com.herobrineboss.entity.HerobrineCloneEntity;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class HerobrineCloneModel extends GeoModel<HerobrineCloneEntity> {
    @Override public ResourceLocation getModelResource(HerobrineCloneEntity entity) {
        return ResourceLocation.fromNamespaceAndPath("herobrine", "geo/herobrine.geo.json");
    }
    @Override public ResourceLocation getTextureResource(HerobrineCloneEntity entity) {
        return ResourceLocation.fromNamespaceAndPath("herobrine", "textures/entity/herobrine.png");
    }
    @Override public ResourceLocation getAnimationResource(HerobrineCloneEntity entity) {
        return ResourceLocation.fromNamespaceAndPath("herobrine", "animations/herobrine.animation.json");
    }
}
