package com.herobrineboss.client;

import com.herobrineboss.entity.HerobrineEntity;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class HerobrineModel extends GeoModel<HerobrineEntity> {
    @Override public ResourceLocation getModelResource(HerobrineEntity animatable) {
        return ResourceLocation.fromNamespaceAndPath("herobrine", "geo/herobrine.geo.json");
    }
    @Override public ResourceLocation getTextureResource(HerobrineEntity animatable) {
        return ResourceLocation.fromNamespaceAndPath("herobrine", "textures/entity/herobrine.png");
    }
    @Override public ResourceLocation getAnimationResource(HerobrineEntity animatable) {
        return ResourceLocation.fromNamespaceAndPath("herobrine", "animations/herobrine.animation.json");
    }
}
