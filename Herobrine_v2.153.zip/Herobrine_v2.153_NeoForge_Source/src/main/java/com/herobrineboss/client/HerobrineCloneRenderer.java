package com.herobrineboss.client;

import com.herobrineboss.entity.HerobrineCloneEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class HerobrineCloneRenderer extends GeoEntityRenderer<HerobrineCloneEntity> {
    public HerobrineCloneRenderer(EntityRendererProvider.Context context) {
        super(context, new HerobrineCloneModel());
        this.shadowRadius = 0.45f;
    }
}
