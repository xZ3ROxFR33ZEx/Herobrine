package com.herobrineboss.client;

import com.herobrineboss.entity.HerobrineEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class HerobrineRenderer extends GeoEntityRenderer<HerobrineEntity> {
    public HerobrineRenderer(EntityRendererProvider.Context context) {
        super(context, new HerobrineModel());
        this.shadowRadius = 0.45f;
    }
}
