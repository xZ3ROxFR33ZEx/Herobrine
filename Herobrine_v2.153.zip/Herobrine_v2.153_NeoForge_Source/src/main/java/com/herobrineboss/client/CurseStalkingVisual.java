package com.herobrineboss.client;

import com.herobrineboss.HerobrineMod;
import com.herobrineboss.entity.HerobrineEntity;
import com.herobrineboss.registry.ModEntities;
import com.herobrineboss.registry.ModItems;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import org.lwjgl.glfw.GLFW;

/** Local visual-only apparition: never spawned or synchronized on the server. */
@EventBusSubscriber(modid = HerobrineMod.MOD_ID, value = Dist.CLIENT)
public final class CurseStalkingVisual {
    private static HerobrineEntity apparition;
    private static long nextAppearance = -1;
    private static long disappearance = 0;
    private static long lastTick = Long.MIN_VALUE;
    private static double x, y, z;
    private static boolean diagnostics = false;
    private static boolean f9WasDown = false;

    @SubscribeEvent
    public static void render(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) { reset(); return; }
        boolean f9Down = GLFW.glfwGetKey(mc.getWindow().getWindow(), GLFW.GLFW_KEY_F9) == GLFW.GLFW_PRESS;
        if (f9Down && !f9WasDown) {
            diagnostics = !diagnostics;
            mc.player.displayClientMessage(Component.literal("[Herobrine] Stalking diagnostics " + (diagnostics ? "ON" : "OFF")), false);
        }
        f9WasDown = f9Down;

        boolean cursed = mc.player.getInventory().contains(new net.minecraft.world.item.ItemStack(ModItems.CURSED_BEDROCK_SWORD.get()))
            || mc.player.getOffhandItem().is(ModItems.CURSED_BEDROCK_SWORD.get());
        if (!cursed) { reset(); return; }
        long now = mc.level.getGameTime();
        if (now < lastTick) { reset(); }
        lastTick = now;
        if (nextAppearance < 0) nextAppearance = now + 20; // First sighting shortly after picking up the sword.
        if (now >= disappearance) apparition = null;
        if (now >= nextAppearance) {
            // Prefer visible positions, with occasional appearances behind the player.
            boolean ahead = mc.level.random.nextFloat() < 0.85f;
            double yaw = Math.toRadians(mc.player.getYRot());
            double angle = ahead ? yaw + Math.PI / 2 + (mc.level.random.nextDouble() - 0.5) * 1.7
                                 : mc.level.random.nextDouble() * Math.PI * 2;
            boolean found = false;
            for (int attempt = 0; attempt < 12; attempt++) {
                double distance = 25 + mc.level.random.nextDouble() * 20;
                double candidateX = mc.player.getX() + Math.cos(angle) * distance;
                double candidateZ = mc.player.getZ() + Math.sin(angle) * distance;
                int bx = (int)Math.floor(candidateX), bz = (int)Math.floor(candidateZ);
                if (mc.level.hasChunk(bx >> 4, bz >> 4)) {
                    int ground = mc.level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, bx, bz);
                    BlockPos feet = new BlockPos(bx, ground, bz);
                    if (mc.level.getBlockState(feet).isAir() && mc.level.getBlockState(feet.above()).isAir()
                        && Math.abs(ground - mc.player.getY()) < 16) {
                        x = candidateX; y = ground; z = candidateZ;
                        found = true;
                        break;
                    }
                }
                angle += (mc.level.random.nextDouble() - 0.5) * 0.55;
            }
            if (found) {
                apparition = new HerobrineEntity(ModEntities.HEROBRINE.get(), mc.level);
                apparition.setPos(x, y, z);
                disappearance = now + 120 + mc.level.random.nextInt(81); // 6-10 seconds.
                nextAppearance = now + 600 + mc.level.random.nextInt(601); // 30-60 seconds.
                if (diagnostics) mc.player.displayClientMessage(Component.literal("[Herobrine] Apparition at " + (int)x + ", " + (int)y + ", " + (int)z), false);
            } else {
                nextAppearance = now + 100;
                if (diagnostics) mc.player.displayClientMessage(Component.literal("[Herobrine] No suitable loaded surface; retrying"), false);
            }
        }
        if (apparition == null || now >= disappearance) return;
        // Vanish if the wielder approaches too closely.
        if (mc.player.distanceToSqr(x, y, z) < 64) {
            apparition = null;
            if (diagnostics) mc.player.displayClientMessage(Component.literal("[Herobrine] Apparition vanished"), false);
            return;
        }
        apparition.setYRot((float)(Math.atan2(mc.player.getZ() - z, mc.player.getX() - x) * 180 / Math.PI - 90));
        Vec3 camera = event.getCamera().getPosition();
        mc.getEntityRenderDispatcher().render(apparition, x - camera.x, y - camera.y,
            z - camera.z, apparition.getYRot(), 0f, event.getPoseStack(),
            mc.renderBuffers().bufferSource(), 15728880);
    }

    private static void reset() {
        apparition = null;
        nextAppearance = -1;
        disappearance = 0;
        lastTick = Long.MIN_VALUE;
    }
}
