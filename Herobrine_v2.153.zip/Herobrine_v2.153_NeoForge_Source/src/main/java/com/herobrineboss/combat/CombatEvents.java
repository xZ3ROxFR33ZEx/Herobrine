package com.herobrineboss.combat;

import com.herobrineboss.HerobrineMod;
import com.herobrineboss.item.BoundSwordItem;
import com.herobrineboss.registry.ModItems;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

/** No direct dependency on either industrial mod: compatibility uses stable registry IDs. */
public final class CombatEvents {
    private CombatEvents() {}
    private static final ResourceKey<DamageType> PIERCING = ResourceKey.create(Registries.DAMAGE_TYPE,
        ResourceLocation.fromNamespaceAndPath(HerobrineMod.MOD_ID, "divine_piercing"));
    private static final ThreadLocal<Boolean> REDIRECTING = ThreadLocal.withInitial(() -> false);

    private static boolean isIndustrialItem(ItemStack stack) {
        if (stack.isEmpty()) return false;
        ResourceLocation id = BuiltInRegistries.ITEM.getKey(stack.getItem());
        String ns = id.getNamespace(), path = id.getPath();
        if (ns.equals("modern_industrialization")) return path.equals("quantum_sword");
        if (!ns.equals("extended_industrialization")) return false;
        return path.equals("nano_saber") || path.equals("nano_quantum_saber")
            || ((path.contains("nano") || path.contains("quantum"))
                && (path.contains("sword") || path.contains("saber") || path.contains("weapon")));
    }

    public static boolean isIndustrialWeaponAttack(DamageSource source) {
        Entity direct = source.getDirectEntity();
        if (direct != null && direct.getType().toString().contains("nano_saber_sweep")) return true;
        Entity owner = source.getEntity();
        if (owner instanceof LivingEntity living) {
            return isIndustrialItem(living.getMainHandItem()) || isIndustrialItem(living.getOffhandItem());
        }
        return false;
    }

    private static int pieces(LivingEntity victim) {
        int count = 0;
        if (victim.getItemBySlot(EquipmentSlot.HEAD).is(ModItems.BEDROCK_HELMET.get())) count++;
        if (victim.getItemBySlot(EquipmentSlot.CHEST).is(ModItems.BEDROCK_CHESTPLATE.get())) count++;
        if (victim.getItemBySlot(EquipmentSlot.LEGS).is(ModItems.BEDROCK_LEGGINGS.get())) count++;
        if (victim.getItemBySlot(EquipmentSlot.FEET).is(ModItems.BEDROCK_BOOTS.get())) count++;
        return count;
    }

    public static boolean industrialArmor(LivingEntity victim) {
        for (EquipmentSlot slot : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST,
                EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
            ItemStack stack = victim.getItemBySlot(slot);
            if (stack.isEmpty()) continue;
            ResourceLocation id = BuiltInRegistries.ITEM.getKey(stack.getItem());
            String ns = id.getNamespace(), path = id.getPath();
            if (ns.equals("modern_industrialization") && path.startsWith("quantum_")) return true;
            if (ns.equals("extended_industrialization") &&
                (path.startsWith("nano_") || path.startsWith("quantum_nano_") || path.startsWith("nano_quantum_"))) return true;
        }
        return false;
    }

    /**
     * v2.151: server-side last-resort HP reconciliation for the industrial armor sets.
     * Some powered suits absorb/cancel the entire hurt() transaction. A damage type
     * with bypasses_armor does not necessarily bypass custom energy shields.
     *
     * Attempt the normal piercing damage first to preserve hit events and effects.
     * If the target still has more HP than the attack should have removed, apply
     * only the missing portion directly. This avoids double damage and keeps
     * other armor and ordinary combat unchanged. Never override creative,
     * spectator, or dead-player protection.
     */
    public static boolean herobrineStrike(LivingEntity victim, DamageSource original, float damage) {
        if (!industrialArmor(victim)) return victim.hurt(original, damage);
        if (victim.level().isClientSide() || !victim.isAlive() || damage <= 0f) return false;
        if (victim instanceof Player player && (player.isCreative() || player.isSpectator())) return false;

        float before = victim.getHealth();
        var holder = victim.level().registryAccess().registryOrThrow(Registries.DAMAGE_TYPE)
            .getHolderOrThrow(PIERCING);
        boolean accepted = victim.hurt(new DamageSource(holder, original.getDirectEntity(), original.getEntity()), damage);
        if (!victim.isAlive()) return true;

        // Herobrine's attacks are meant to penetrate these specific energy suits.
        // The fallback is intentionally limited to the recognized armor items.
        float expected = Math.max(0f, before - damage);
        if (victim.getHealth() > expected) {
            victim.setHealth(expected);
            return true;
        }
        return accepted;
    }

    private static BoundSwordItem.Kind swordKind(DamageSource source) {
        if (source.getDirectEntity() != source.getEntity()) return null;
        if (source.getEntity() instanceof LivingEntity attacker) {
            ItemStack weapon = attacker.getMainHandItem();
            if (weapon.getItem() instanceof BoundSwordItem sword) return sword.kind();
        }
        return null;
    }

    @SubscribeEvent
    public static void incoming(LivingIncomingDamageEvent event) {
        if (event.getEntity().level().isClientSide()) return;
        LivingEntity target = event.getEntity();
        if (isIndustrialWeaponAttack(event.getSource()) && pieces(target) == 4) {
            event.setCanceled(true);
            return;
        }
        if (REDIRECTING.get()) return;
        BoundSwordItem.Kind kind = swordKind(event.getSource());
        if (kind == null || !industrialArmor(target)) return;
        // A dedicated damage type skips vanilla armor, enchantment, resistance and effects.
        // This also avoids the industrial mods' ordinary armor attribute mitigation.
        event.setCanceled(true);
        float bonus = multiplier(kind, target, event.getSource().getEntity());
        float damage = Math.max(0f, event.getAmount() * bonus);
        var holder = target.level().registryAccess().registryOrThrow(Registries.DAMAGE_TYPE)
            .getHolderOrThrow(PIERCING);
        try {
            REDIRECTING.set(true);
            target.hurt(new DamageSource(holder, event.getSource().getDirectEntity(), event.getSource().getEntity()), damage);
        } finally {
            REDIRECTING.remove();
        }
    }

    private static float multiplier(BoundSwordItem.Kind kind, LivingEntity target, Entity attacker) {
        if (kind == BoundSwordItem.Kind.CREATOR && target.getMaxHealth() > 200f) return 1.5f;
        if (kind == BoundSwordItem.Kind.CURSED) {
            if (attacker instanceof LivingEntity living && living.getHealth() < living.getMaxHealth() * 0.5f)
                return 1.4f;
            return 1.25f;
        }
        return 1f;
    }

    @SubscribeEvent
    public static void afterArmor(LivingDamageEvent.Pre event) {
        if (event.getEntity().level().isClientSide()) return;
        if (isIndustrialWeaponAttack(event.getSource())) {
            int count = pieces(event.getEntity());
            float reduction = switch (count) { case 1 -> 0.2f; case 2 -> 0.4f;
                case 3 -> 0.6f; case 4 -> 1f; default -> 0f; };
            event.setNewDamage(event.getNewDamage() * (1f - reduction));
        }
        if (!REDIRECTING.get() && !industrialArmor(event.getEntity())) {
            BoundSwordItem.Kind kind = swordKind(event.getSource());
            if (kind != null) event.setNewDamage(event.getNewDamage() *
                multiplier(kind, event.getEntity(), event.getSource().getEntity()));
        }
    }

    @SubscribeEvent
    public static void regenerate(PlayerTickEvent.Post event) {
        Player player = event.getEntity();
        if (player.level().isClientSide() || player.tickCount % 20 != 0) return;
        ItemStack stack = player.getMainHandItem();
        if (stack.is(ModItems.CREATORS_BLADE.get()) || stack.is(ModItems.CURSED_BEDROCK_SWORD.get())) {
            if (player.isAlive() && player.getHealth() < player.getMaxHealth()) player.heal(2f);
        }
    }
}
